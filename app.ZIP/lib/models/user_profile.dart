import 'package:cloud_firestore/cloud_firestore.dart';

class UserProfile {
  final String uid;
  final String email;
  final String name;
  final String? photoURL;
  final String provider;
  final DateTime? createdAt;
  final DateTime? lastLogin;
  final int loginCount;

  UserProfile({
    required this.uid,
    required this.email,
    required this.name,
    this.photoURL,
    this.provider = 'google',
    this.createdAt,
    this.lastLogin,
    this.loginCount = 1,
  });

  factory UserProfile.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return UserProfile.fromMap(doc.id, data);
  }

  factory UserProfile.fromMap(String uid, Map<String, dynamic> data) {
    return UserProfile(
      uid: uid,
      email: data['email'] as String? ?? '',
      name: data['name'] as String? ?? 'MART User',
      photoURL: data['photoURL'] as String?,
      provider: data['provider'] as String? ?? 'google',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      lastLogin: (data['lastLogin'] as Timestamp?)?.toDate() ?? DateTime.now(),
      loginCount: (data['loginCount'] as num?)?.toInt() ?? 1,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'uid': uid,
      'email': email,
      'name': name,
      'photoURL': photoURL,
      'provider': provider,
      'loginCount': loginCount,
      'lastLogin': FieldValue.serverTimestamp(),
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : FieldValue.serverTimestamp(),
    };
  }
}
