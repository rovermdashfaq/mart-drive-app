import 'package:cloud_firestore/cloud_firestore.dart';

class AppNotification {
  final String id;
  final String toEmail;
  final String? toUid;
  final String type; // 'notice' | 'warning' | 'login_anomaly' | 'mention'
  final String title;
  final String body;
  final bool read;
  final String? by;
  final String? byName;
  final String? noticeId;
  final DateTime? createdAt;

  AppNotification({
    required this.id,
    required this.toEmail,
    this.toUid,
    required this.type,
    required this.title,
    required this.body,
    this.read = false,
    this.by,
    this.byName,
    this.noticeId,
    this.createdAt,
  });

  bool get isWarning => type == 'warning';
  bool get isNotice => type == 'notice';
  bool get isAnomaly => type == 'login_anomaly';

  factory AppNotification.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return AppNotification.fromMap(doc.id, data);
  }

  factory AppNotification.fromMap(String id, Map<String, dynamic> data) {
    return AppNotification(
      id: id,
      toEmail: data['toEmail'] as String? ?? '',
      toUid: data['toUid'] as String?,
      type: data['type'] as String? ?? 'notice',
      title: data['title'] as String? ?? '',
      body: data['body'] as String? ?? '',
      read: data['read'] as bool? ?? false,
      by: data['by'] as String?,
      byName: data['byName'] as String?,
      noticeId: data['noticeId'] as String?,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'toEmail': toEmail,
      'toUid': toUid,
      'type': type,
      'title': title,
      'body': body,
      'read': read,
      'by': by,
      'byName': byName,
      'noticeId': noticeId,
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : FieldValue.serverTimestamp(),
    };
  }
}
