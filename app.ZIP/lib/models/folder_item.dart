import 'package:cloud_firestore/cloud_firestore.dart';
import 'file_item.dart';

class FolderItem {
  final String id;
  final String name;
  final String? icon;
  final String? parentId;
  final String? orgId;
  final String uid;
  final String? by;
  final bool starred;
  final bool trashed;
  final String? trashRoot;
  final DateTime? trashedAt;
  final List<AclEntry> acl;
  final List<String> aclEmails;
  final String? linkRoot;
  final bool vault;
  final int? order;
  final DateTime? createdAt;

  FolderItem({
    required this.id,
    required this.name,
    this.icon,
    this.parentId,
    this.orgId,
    required this.uid,
    this.by,
    this.starred = false,
    this.trashed = false,
    this.trashRoot,
    this.trashedAt,
    this.acl = const [],
    this.aclEmails = const [],
    this.linkRoot,
    this.vault = false,
    this.order,
    this.createdAt,
  });

  factory FolderItem.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return FolderItem.fromMap(doc.id, data);
  }

  factory FolderItem.fromMap(String id, Map<String, dynamic> data) {
    final aclRaw = data['acl'] as List<dynamic>? ?? [];
    return FolderItem(
      id: id,
      name: data['name'] as String? ?? 'Untitled Folder',
      icon: data['icon'] as String?,
      parentId: data['parentId'] as String?,
      orgId: data['orgId'] as String?,
      uid: data['uid'] as String? ?? '',
      by: data['by'] as String?,
      starred: data['starred'] as bool? ?? false,
      trashed: data['trashed'] as bool? ?? false,
      trashRoot: data['trashRoot'] as String?,
      trashedAt: (data['trashedAt'] as Timestamp?)?.toDate(),
      acl: aclRaw.map((e) => AclEntry.fromMap(Map<String, dynamic>.from(e as Map))).toList(),
      aclEmails: (data['aclEmails'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      linkRoot: data['linkRoot'] as String?,
      vault: data['vault'] as bool? ?? false,
      order: (data['order'] as num?)?.toInt(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'icon': icon,
      'parentId': parentId,
      'orgId': orgId,
      'uid': uid,
      'by': by,
      'starred': starred,
      'trashed': trashed,
      'trashRoot': trashRoot,
      'trashedAt': trashedAt != null ? Timestamp.fromDate(trashedAt!) : null,
      'acl': acl.map((a) => a.toMap()).toList(),
      'aclEmails': aclEmails,
      'linkRoot': linkRoot,
      'vault': vault,
      'order': order,
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : FieldValue.serverTimestamp(),
    };
  }

  FolderItem copyWith({
    String? name,
    String? icon,
    String? parentId,
    bool? starred,
    bool? trashed,
    bool? vault,
  }) {
    return FolderItem(
      id: id,
      name: name ?? this.name,
      icon: icon ?? this.icon,
      parentId: parentId ?? this.parentId,
      orgId: orgId,
      uid: uid,
      by: by,
      starred: starred ?? this.starred,
      trashed: trashed ?? this.trashed,
      trashRoot: trashRoot,
      trashedAt: trashedAt,
      acl: acl,
      aclEmails: aclEmails,
      linkRoot: linkRoot,
      vault: vault ?? this.vault,
      order: order,
      createdAt: createdAt,
    );
  }
}
