import 'package:cloud_firestore/cloud_firestore.dart';

class ShareItem {
  final String id;
  final String fileId;
  final String driveFileId;
  final String name;
  final String mimeType;
  final int size;
  final String ownerUid;
  final String ownerEmail;
  final String email;
  final String role; // 'reader' | 'commenter' | 'writer'
  final String? permId;
  final DateTime? createdAt;

  ShareItem({
    required this.id,
    required this.fileId,
    required this.driveFileId,
    required this.name,
    required this.mimeType,
    required this.size,
    required this.ownerUid,
    required this.ownerEmail,
    required this.email,
    required this.role,
    this.permId,
    this.createdAt,
  });

  factory ShareItem.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return ShareItem(
      id: doc.id,
      fileId: data['fileId'] as String? ?? '',
      driveFileId: data['driveFileId'] as String? ?? '',
      name: data['name'] as String? ?? 'Shared File',
      mimeType: data['mimeType'] as String? ?? 'application/octet-stream',
      size: (data['size'] as num?)?.toInt() ?? 0,
      ownerUid: data['ownerUid'] as String? ?? '',
      ownerEmail: data['ownerEmail'] as String? ?? '',
      email: data['email'] as String? ?? '',
      role: data['role'] as String? ?? 'reader',
      permId: data['permId'] as String?,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'fileId': fileId,
      'driveFileId': driveFileId,
      'name': name,
      'mimeType': mimeType,
      'size': size,
      'ownerUid': ownerUid,
      'ownerEmail': ownerEmail,
      'email': email,
      'role': role,
      'permId': permId,
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : FieldValue.serverTimestamp(),
    };
  }
}

class FolderJoinItem {
  final String id;
  final String rootId;
  final String folderId;
  final String role;
  final String name;
  final String ownerUid;
  final String ownerEmail;
  final String email;

  FolderJoinItem({
    required this.id,
    required this.rootId,
    required this.folderId,
    required this.role,
    required this.name,
    required this.ownerUid,
    required this.ownerEmail,
    required this.email,
  });

  factory FolderJoinItem.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return FolderJoinItem(
      id: doc.id,
      rootId: data['rootId'] as String? ?? '',
      folderId: data['folderId'] as String? ?? '',
      role: data['role'] as String? ?? 'reader',
      name: data['name'] as String? ?? 'Shared Folder',
      ownerUid: data['ownerUid'] as String? ?? '',
      ownerEmail: data['ownerEmail'] as String? ?? '',
      email: data['email'] as String? ?? '',
    );
  }
}
