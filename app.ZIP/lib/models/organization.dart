import 'package:cloud_firestore/cloud_firestore.dart';

class Organization {
  final String id;
  final String name;
  final String? teamName;
  final String? logoUrl;
  final String owner; // uid
  final String ownerEmail;
  final List<String> founders; // Super admins
  final List<String> owners; // Admins
  final List<String> members; // Members
  final String? inviteCode;
  final bool autoApprove;
  final int trashDays;
  final bool? premiumLook;
  final DateTime? createdAt;

  Organization({
    required this.id,
    required this.name,
    this.teamName,
    this.logoUrl,
    required this.owner,
    required this.ownerEmail,
    this.founders = const [],
    this.owners = const [],
    this.members = const [],
    this.inviteCode,
    this.autoApprove = true,
    this.trashDays = 30,
    this.premiumLook,
    this.createdAt,
  });

  /// Check if an organization qualifies for the gold premium look:
  /// members count >= 10 and premiumLook != false
  bool get isPremium => members.length >= 10 && premiumLook != false;

  bool isFounder(String email) => founders.contains(email.toLowerCase());
  bool isOwner(String email) => owners.contains(email.toLowerCase()) || isFounder(email);
  bool isMember(String email) => members.contains(email.toLowerCase()) || isOwner(email);

  factory Organization.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return Organization.fromMap(doc.id, data);
  }

  factory Organization.fromMap(String id, Map<String, dynamic> data) {
    final foundersList = (data['founders'] as List<dynamic>?)
            ?.map((e) => e.toString().toLowerCase())
            .toList() ??
        [];
    final ownersList = (data['owners'] as List<dynamic>?)
            ?.map((e) => e.toString().toLowerCase())
            .toList() ??
        [];
    final membersList = (data['members'] as List<dynamic>?)
            ?.map((e) => e.toString().toLowerCase())
            .toList() ??
        [];

    final ownerEmail = (data['ownerEmail'] as String? ?? '').toLowerCase();

    // Ensure invariants: creator always in founders, owners, members
    if (ownerEmail.isNotEmpty) {
      if (!foundersList.contains(ownerEmail)) foundersList.add(ownerEmail);
      if (!ownersList.contains(ownerEmail)) ownersList.add(ownerEmail);
      if (!membersList.contains(ownerEmail)) membersList.add(ownerEmail);
    }

    return Organization(
      id: id,
      name: data['name'] as String? ?? 'Unnamed Org',
      teamName: data['teamName'] as String?,
      logoUrl: data['logoUrl'] as String?,
      owner: data['owner'] as String? ?? '',
      ownerEmail: ownerEmail,
      founders: foundersList,
      owners: ownersList,
      members: membersList,
      inviteCode: data['inviteCode'] as String?,
      autoApprove: data['autoApprove'] as bool? ?? true,
      trashDays: (data['trashDays'] as num?)?.toInt() ?? 30,
      premiumLook: data['premiumLook'] as bool?,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'teamName': teamName,
      'logoUrl': logoUrl,
      'owner': owner,
      'ownerEmail': ownerEmail.toLowerCase(),
      'founders': founders.map((e) => e.toLowerCase()).toList(),
      'owners': owners.map((e) => e.toLowerCase()).toList(),
      'members': members.map((e) => e.toLowerCase()).toList(),
      'inviteCode': inviteCode,
      'autoApprove': autoApprove,
      'trashDays': trashDays,
      'premiumLook': premiumLook,
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : FieldValue.serverTimestamp(),
    };
  }
}
