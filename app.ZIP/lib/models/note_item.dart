import 'package:cloud_firestore/cloud_firestore.dart';

class LinkPreviewData {
  final String? title;
  final String? description;
  final String? image;
  final String? logo;
  final String? site;

  LinkPreviewData({
    this.title,
    this.description,
    this.image,
    this.logo,
    this.site,
  });

  factory LinkPreviewData.fromMap(Map<String, dynamic> map) {
    return LinkPreviewData(
      title: map['title'] as String?,
      description: map['description'] as String?,
      image: map['image'] as String?,
      logo: map['logo'] as String?,
      site: map['site'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
    'title': title,
    'description': description,
    'image': image,
    'logo': logo,
    'site': site,
  };
}

class NoteItem {
  final String id;
  final String name;
  final String ntype; // 'note' | 'link'
  final String content;
  final String? url;
  final LinkPreviewData? preview;
  final String color;
  final String? folderId;
  final String? orgId;
  final String uid;
  final String? by;
  final bool starred;
  final bool trashed;
  final String? linkRoot;
  final bool vault;
  final List<String> tags;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  NoteItem({
    required this.id,
    required this.name,
    this.ntype = 'note',
    this.content = '',
    this.url,
    this.preview,
    this.color = '',
    this.folderId,
    this.orgId,
    required this.uid,
    this.by,
    this.starred = false,
    this.trashed = false,
    this.linkRoot,
    this.vault = false,
    this.tags = const [],
    this.createdAt,
    this.updatedAt,
  });

  bool get isLink => ntype == 'link';

  factory NoteItem.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return NoteItem.fromMap(doc.id, data);
  }

  factory NoteItem.fromMap(String id, Map<String, dynamic> data) {
    LinkPreviewData? previewData;
    if (data['preview'] is Map) {
      previewData = LinkPreviewData.fromMap(Map<String, dynamic>.from(data['preview'] as Map));
    }

    return NoteItem(
      id: id,
      name: data['name'] as String? ?? 'Untitled',
      ntype: data['ntype'] as String? ?? 'note',
      content: data['content'] as String? ?? '',
      url: data['url'] as String?,
      preview: previewData,
      color: data['color'] as String? ?? '',
      folderId: data['folderId'] as String?,
      orgId: data['orgId'] as String?,
      uid: data['uid'] as String? ?? '',
      by: data['by'] as String?,
      starred: data['starred'] as bool? ?? false,
      trashed: data['trashed'] as bool? ?? false,
      linkRoot: data['linkRoot'] as String?,
      vault: data['vault'] as bool? ?? false,
      tags: (data['tags'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'ntype': ntype,
      'content': content,
      'url': url,
      'preview': preview?.toMap(),
      'color': color,
      'folderId': folderId,
      'orgId': orgId,
      'uid': uid,
      'by': by,
      'starred': starred,
      'trashed': trashed,
      'linkRoot': linkRoot,
      'vault': vault,
      'tags': tags,
      'updatedAt': FieldValue.serverTimestamp(),
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : FieldValue.serverTimestamp(),
    };
  }

  NoteItem copyWith({
    String? name,
    String? content,
    String? color,
    bool? starred,
    bool? trashed,
    bool? vault,
    LinkPreviewData? preview,
    List<String>? tags,
  }) {
    return NoteItem(
      id: id,
      name: name ?? this.name,
      ntype: ntype,
      content: content ?? this.content,
      url: url,
      preview: preview ?? this.preview,
      color: color ?? this.color,
      folderId: folderId,
      orgId: orgId,
      uid: uid,
      by: by,
      starred: starred ?? this.starred,
      trashed: trashed ?? this.trashed,
      linkRoot: linkRoot,
      vault: vault ?? this.vault,
      tags: tags ?? this.tags,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }
}
