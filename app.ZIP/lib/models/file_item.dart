import 'package:cloud_firestore/cloud_firestore.dart';

class AclEntry {
  final String email;
  final String role; // 'reader' | 'commenter' | 'writer'

  AclEntry({required this.email, required this.role});

  factory AclEntry.fromMap(Map<String, dynamic> map) {
    return AclEntry(
      email: map['e'] as String? ?? '',
      role: map['r'] as String? ?? 'reader',
    );
  }

  Map<String, dynamic> toMap() => {'e': email, 'r': role};
}

class FileItem {
  final String id;
  final String driveFileId;
  final String name;
  final String mimeType;
  final int size;
  final String? folderId;
  final String? orgId;
  final String uid;
  final String? by;
  final bool starred;
  final bool trashed;
  final String? trashRoot;
  final DateTime? trashedAt;
  final String? thumb;
  final List<String> grantedTo;
  final List<AclEntry> acl;
  final List<String> aclEmails;
  final String? linkRoot;
  final bool vault;
  final List<String> tags;
  final int? order;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  FileItem({
    required this.id,
    required this.driveFileId,
    required this.name,
    required this.mimeType,
    required this.size,
    this.folderId,
    this.orgId,
    required this.uid,
    this.by,
    this.starred = false,
    this.trashed = false,
    this.trashRoot,
    this.trashedAt,
    this.thumb,
    this.grantedTo = const [],
    this.acl = const [],
    this.aclEmails = const [],
    this.linkRoot,
    this.vault = false,
    this.tags = const [],
    this.order,
    this.createdAt,
    this.updatedAt,
  });

  factory FileItem.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return FileItem.fromMap(doc.id, data);
  }

  factory FileItem.fromMap(String id, Map<String, dynamic> data) {
    final aclRaw = data['acl'] as List<dynamic>? ?? [];
    return FileItem(
      id: id,
      driveFileId: data['driveFileId'] as String? ?? '',
      name: data['name'] as String? ?? 'Untitled',
      mimeType: data['mimeType'] as String? ?? 'application/octet-stream',
      size: (data['size'] as num?)?.toInt() ?? 0,
      folderId: data['folderId'] as String?,
      orgId: data['orgId'] as String?,
      uid: data['uid'] as String? ?? '',
      by: data['by'] as String?,
      starred: data['starred'] as bool? ?? false,
      trashed: data['trashed'] as bool? ?? false,
      trashRoot: data['trashRoot'] as String?,
      trashedAt: (data['trashedAt'] as Timestamp?)?.toDate(),
      thumb: data['thumb'] as String?,
      grantedTo: (data['grantedTo'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      acl: aclRaw.map((e) => AclEntry.fromMap(Map<String, dynamic>.from(e as Map))).toList(),
      aclEmails: (data['aclEmails'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      linkRoot: data['linkRoot'] as String?,
      vault: data['vault'] as bool? ?? false,
      tags: (data['tags'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      order: (data['order'] as num?)?.toInt(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'driveFileId': driveFileId,
      'name': name,
      'mimeType': mimeType,
      'size': size,
      'folderId': folderId,
      'orgId': orgId,
      'uid': uid,
      'by': by,
      'starred': starred,
      'trashed': trashed,
      'trashRoot': trashRoot,
      'trashedAt': trashedAt != null ? Timestamp.fromDate(trashedAt!) : null,
      'thumb': thumb,
      'grantedTo': grantedTo,
      'acl': acl.map((a) => a.toMap()).toList(),
      'aclEmails': aclEmails,
      'linkRoot': linkRoot,
      'vault': vault,
      'tags': tags,
      'order': order,
      'updatedAt': FieldValue.serverTimestamp(),
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : FieldValue.serverTimestamp(),
    };
  }

  FileItem copyWith({
    String? name,
    bool? starred,
    bool? trashed,
    String? folderId,
    String? thumb,
    List<String>? tags,
    bool? vault,
  }) {
    return FileItem(
      id: id,
      driveFileId: driveFileId,
      name: name ?? this.name,
      mimeType: mimeType,
      size: size,
      folderId: folderId ?? this.folderId,
      orgId: orgId,
      uid: uid,
      by: by,
      starred: starred ?? this.starred,
      trashed: trashed ?? this.trashed,
      trashRoot: trashRoot,
      trashedAt: trashedAt,
      thumb: thumb ?? this.thumb,
      grantedTo: grantedTo,
      acl: acl,
      aclEmails: aclEmails,
      linkRoot: linkRoot,
      vault: vault ?? this.vault,
      tags: tags ?? this.tags,
      order: order,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }
}
