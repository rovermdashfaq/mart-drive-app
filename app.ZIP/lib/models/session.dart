import 'package:cloud_firestore/cloud_firestore.dart';

class UserSession {
  final String id;
  final String uid;
  final String sid;
  final String browser;
  final String os;
  final String device;
  final String? country;
  final DateTime? lastSeen;
  final bool revoked;

  UserSession({
    required this.id,
    required this.uid,
    required this.sid,
    required this.browser,
    required this.os,
    required this.device,
    this.country,
    this.lastSeen,
    this.revoked = false,
  });

  factory UserSession.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return UserSession.fromMap(doc.id, data);
  }

  factory UserSession.fromMap(String id, Map<String, dynamic> data) {
    return UserSession(
      id: id,
      uid: data['uid'] as String? ?? '',
      sid: data['sid'] as String? ?? '',
      browser: data['browser'] as String? ?? 'Flutter App',
      os: data['os'] as String? ?? 'Unknown',
      device: data['device'] as String? ?? 'mobile',
      country: data['country'] as String?,
      lastSeen: (data['lastSeen'] as Timestamp?)?.toDate(),
      revoked: data['revoked'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'uid': uid,
      'sid': sid,
      'browser': browser,
      'os': os,
      'device': device,
      'country': country,
      'lastSeen': FieldValue.serverTimestamp(),
      'revoked': revoked,
    };
  }
}
