import 'package:cloud_firestore/cloud_firestore.dart';

class GuestRequest {
  final String id;
  final String code;
  final String orgId;
  final String orgName;
  final String email;
  final String role;
  final String status;
  final List<String> itemIds;

  GuestRequest({
    required this.id,
    required this.code,
    required this.orgId,
    required this.orgName,
    required this.email,
    required this.role,
    required this.status,
    required this.itemIds,
  });

  factory GuestRequest.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return GuestRequest(
      id: doc.id,
      code: data['code'] as String? ?? '',
      orgId: data['orgId'] as String? ?? '',
      orgName: data['orgName'] as String? ?? '',
      email: data['email'] as String? ?? '',
      role: data['role'] as String? ?? 'reader',
      status: data['status'] as String? ?? 'pending',
      itemIds: (data['itemIds'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
    );
  }
}

class JoinRequest {
  final String id;
  final String orgId;
  final String orgName;
  final String email;
  final String name;
  final String? photo;
  final String uid;
  final String status; // 'pending' | 'approved' | 'rejected'
  final bool auto;

  JoinRequest({
    required this.id,
    required this.orgId,
    required this.orgName,
    required this.email,
    required this.name,
    this.photo,
    required this.uid,
    required this.status,
    this.auto = false,
  });

  factory JoinRequest.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return JoinRequest(
      id: doc.id,
      orgId: data['orgId'] as String? ?? '',
      orgName: data['orgName'] as String? ?? '',
      email: data['email'] as String? ?? '',
      name: data['name'] as String? ?? '',
      photo: data['photo'] as String?,
      uid: data['uid'] as String? ?? '',
      status: data['status'] as String? ?? 'pending',
      auto: data['auto'] as bool? ?? false,
    );
  }
}
