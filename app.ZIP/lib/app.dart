import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/auth_provider.dart';
import 'core/constants.dart';
import 'core/router.dart';
import 'core/theme.dart';

class MartDriveApp extends ConsumerWidget {
  const MartDriveApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(appThemeProvider);
    final router = ref.watch(routerProvider);
    final systemBrightness = MediaQuery.platformBrightnessOf(context);

    return MaterialApp.router(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppThemes.getTheme(themeMode, systemBrightness),
      routerConfig: router,
    );
  }
}
