import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:pointycastle/key_derivators/pbkdf2.dart';
import 'package:pointycastle/macs/hmac.dart';
import 'package:pointycastle/digests/sha256.dart';
import 'package:pointycastle/pointycastle.dart';
import '../core/constants.dart';

class VaultService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  bool _isUnlocked = false;
  DateTime? _lastActivityTime;
  int _failedAttempts = 0;
  DateTime? _lockoutUntil;

  bool get isUnlocked {
    if (!_isUnlocked) return false;
    // Auto-lock after 5 minutes of inactivity
    if (_lastActivityTime != null &&
        DateTime.now().difference(_lastActivityTime!) > AppConstants.vaultAutoLockTimeout) {
      _isUnlocked = false;
      return false;
    }
    return true;
  }

  void recordActivity() {
    _lastActivityTime = DateTime.now();
  }

  void lock() {
    _isUnlocked = false;
  }

  Uint8List _generateSalt([int length = AppConstants.saltBytes]) {
    final random = Random.secure();
    return Uint8List.fromList(List<int>.generate(length, (_) => random.nextInt(256)));
  }

  String _hashPin(String pin, Uint8List salt) {
    final pbkdf2 = PBKDF2KeyDerivator(HMac(SHA256Digest(), 64))
      ..init(Pbkdf2Parameters(salt, AppConstants.pbkdf2Iterations, 32));
    final key = pbkdf2.process(Uint8List.fromList(utf8.encode(pin)));
    return base64Encode(key);
  }

  /// Check if user has initialized their Vault PIN in userSecurity/{uid}
  Future<bool> hasVaultPin(String uid) async {
    final doc = await _firestore.collection('userSecurity').doc(uid).get();
    if (!doc.exists) return false;
    final data = doc.data();
    return data != null && data['vault'] != null;
  }

  /// Sets or updates the vault PIN in Firestore
  Future<void> setupVaultPin(String uid, String pin) async {
    final salt = _generateSalt();
    final hash = _hashPin(pin, salt);

    await _firestore.collection('userSecurity').doc(uid).set({
      'vault': {
        'pinHash': hash,
        'salt': base64Encode(salt),
        'iter': AppConstants.pbkdf2Iterations,
      }
    }, SetOptions(merge: true));

    _isUnlocked = true;
    recordActivity();
  }

  /// Verifies PIN against Firestore userSecurity/{uid}
  Future<bool> verifyVaultPin(String uid, String pin) async {
    if (_lockoutUntil != null && DateTime.now().isBefore(_lockoutUntil!)) {
      return false;
    }

    final doc = await _firestore.collection('userSecurity').doc(uid).get();
    if (!doc.exists) return false;

    final vaultData = doc.data()?['vault'] as Map<String, dynamic>?;
    if (vaultData == null) return false;

    final salt = base64Decode(vaultData['salt'] as String);
    final expectedHash = vaultData['pinHash'] as String;

    final calculated = _hashPin(pin, salt);
    if (calculated == expectedHash) {
      _isUnlocked = true;
      _failedAttempts = 0;
      _lockoutUntil = null;
      recordActivity();
      return true;
    } else {
      _failedAttempts++;
      if (_failedAttempts >= 5) {
        final multiplier = pow(2, _failedAttempts - 5).toInt();
        final seconds = (30 * multiplier).clamp(30, 900);
        _lockoutUntil = DateTime.now().add(Duration(seconds: seconds));
      }
      return false;
    }
  }

  /// Reset vault PIN (e.g. after Google account re-auth)
  Future<void> resetVault(String uid) async {
    await _firestore.collection('userSecurity').doc(uid).update({
      'vault': FieldValue.delete(),
    });
    _isUnlocked = false;
  }
}
