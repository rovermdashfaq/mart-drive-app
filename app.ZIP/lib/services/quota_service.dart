import 'package:cloud_firestore/cloud_firestore.dart';
import 'drive_service.dart';

class StorageQuotaInfo {
  final int usageBytes;
  final int limitBytes;

  StorageQuotaInfo({required this.usageBytes, required this.limitBytes});

  double get usagePercent => limitBytes > 0 ? (usageBytes / limitBytes).clamp(0.0, 1.0) : 0.0;
}

class MemberQuota {
  final String orgId;
  final String email;
  final String name;
  final int limit;
  final int usage;
  final DateTime? updatedAt;

  MemberQuota({
    required this.orgId,
    required this.email,
    required this.name,
    required this.limit,
    required this.usage,
    this.updatedAt,
  });

  factory MemberQuota.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return MemberQuota(
      orgId: data['orgId'] as String? ?? '',
      email: data['email'] as String? ?? '',
      name: data['name'] as String? ?? '',
      limit: (data['limit'] as num?)?.toInt() ?? 0,
      usage: (data['usage'] as num?)?.toInt() ?? 0,
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
    );
  }
}

class QuotaService {
  final DriveService _driveService = DriveService();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<StorageQuotaInfo> fetchDriveQuota(String accessToken) async {
    try {
      final quotaMap = await _driveService.getStorageQuota(accessToken);
      final usage = int.tryParse(quotaMap['usage']?.toString() ?? '0') ?? 0;
      final limit = int.tryParse(quotaMap['limit']?.toString() ?? '16106127360') ?? 16106127360; // 15 GB
      return StorageQuotaInfo(usageBytes: usage, limitBytes: limit);
    } catch (_) {
      return StorageQuotaInfo(usageBytes: 0, limitBytes: 16106127360);
    }
  }

  Stream<List<MemberQuota>> streamTeamQuotas(String orgId) {
    return _firestore
        .collection('memberQuotas')
        .where('orgId', isEqualTo: orgId)
        .snapshots()
        .map((snap) => snap.docs.map((d) => MemberQuota.fromFirestore(d)).toList());
  }
}
