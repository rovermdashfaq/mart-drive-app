/// 3-way text merge service ported from the MART Drive web application.
/// Accurately merges concurrent local and server text edits using base context.

class MergeResult {
  final String text;
  final bool hasConflict;
  final String? conflictText;

  MergeResult({
    required this.text,
    this.hasConflict = false,
    this.conflictText,
  });
}

class SpanMatch {
  final int prefix;
  final int suffix;

  SpanMatch({required this.prefix, required this.suffix});
}

class MergeService {
  /// Finds common prefix and suffix lengths between two strings.
  static SpanMatch span(String a, String b) {
    int p = 0;
    final int minLen = a.length < b.length ? a.length : b.length;

    while (p < minLen && a.codeUnitAt(p) == b.codeUnitAt(p)) {
      p++;
    }

    int s = 0;
    while (s < (minLen - p) &&
        a.codeUnitAt(a.length - 1 - s) == b.codeUnitAt(b.length - 1 - s)) {
      s++;
    }

    return SpanMatch(prefix: p, suffix: s);
  }

  /// 3-way merge algorithm matching m3(base, mine, server) from the web client.
  static MergeResult m3(String base, String mine, String server) {
    // Trivial cases
    if (mine == server) return MergeResult(text: mine);
    if (mine == base) return MergeResult(text: server);
    if (server == base) return MergeResult(text: mine);

    // Compute edits made in mine relative to base
    final mSpan = span(base, mine);
    final int bMidLenM = base.length - mSpan.prefix - mSpan.suffix;
    final int mMidLen = mine.length - mSpan.prefix - mSpan.suffix;

    // Compute edits made in server relative to base
    final sSpan = span(base, server);
    final int bMidLenS = base.length - sSpan.prefix - sSpan.suffix;
    final int sMidLen = server.length - sSpan.prefix - sSpan.suffix;

    final int mStart = mSpan.prefix;
    final int mEndInBase = base.length - mSpan.suffix;

    final int sStart = sSpan.prefix;
    final int sEndInBase = base.length - sSpan.suffix;

    // Disjoint non-overlapping edits:
    // Case 1: mine is completely before server in base
    if (mEndInBase <= sStart) {
      final mineChunk = mine.substring(mStart, mStart + mMidLen);
      final serverChunk = server.substring(sStart, sStart + sMidLen);

      final prefixBase = base.substring(0, mStart);
      final betweenBase = base.substring(mEndInBase, sStart);
      final suffixBase = base.substring(sEndInBase);

      final result = '$prefixBase$mineChunk$betweenBase$serverChunk$suffixBase';
      return MergeResult(text: result);
    }

    // Case 2: server is completely before mine in base
    if (sEndInBase <= mStart) {
      final serverChunk = server.substring(sStart, sStart + sMidLen);
      final mineChunk = mine.substring(mStart, mStart + mMidLen);

      final prefixBase = base.substring(0, sStart);
      final betweenBase = base.substring(sEndInBase, mStart);
      final suffixBase = base.substring(mEndInBase);

      final result = '$prefixBase$serverChunk$betweenBase$mineChunk$suffixBase';
      return MergeResult(text: result);
    }

    // Overlapping edits -> Conflict.
    // In MART Drive policy: Keep server text, record the conflict/lost local text.
    return MergeResult(
      text: server,
      hasConflict: true,
      conflictText: mine,
    );
  }
}
