import 'dart:async';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/session.dart';
import '../core/constants.dart';

class SessionService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  Timer? _heartbeatTimer;
  StreamSubscription<DocumentSnapshot>? _selfSessionSub;

  String? _currentSessionId;
  String? _currentUid;

  String get currentSessionId => _currentSessionId ?? 'default_session';

  /// Registers session on login and begins periodic heartbeats
  Future<void> registerSession({
    required String uid,
    required String deviceId,
    String? country,
    required VoidCallback onRevoked,
  }) async {
    _currentUid = uid;
    _currentSessionId = '${uid}_$deviceId';

    String osName = 'Unknown';
    if (!kIsWeb) {
      osName = Platform.operatingSystem;
    }

    final docRef = _firestore.collection('userSessions').doc(_currentSessionId);

    await docRef.set({
      'uid': uid,
      'sid': deviceId,
      'browser': 'Flutter App',
      'os': osName,
      'device': 'mobile',
      'country': country ?? 'Global',
      'lastSeen': FieldValue.serverTimestamp(),
      'revoked': false,
    }, SetOptions(merge: true));

    // Listen to self session for revocation
    _selfSessionSub?.cancel();
    _selfSessionSub = docRef.snapshots().listen((snapshot) {
      if (snapshot.exists) {
        final data = snapshot.data();
        if (data != null && data['revoked'] == true) {
          onRevoked();
        }
      }
    });

    // Start 3-minute heartbeat
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(AppConstants.sessionHeartbeatInterval, (_) {
      docRef.update({'lastSeen': FieldValue.serverTimestamp()}).catchError((_) {});
    });
  }

  /// Fetches all active sessions for current user
  Stream<List<UserSession>> streamUserSessions(String uid) {
    return _firestore
        .collection('userSessions')
        .where('uid', isEqualTo: uid)
        .where('revoked', isEqualTo: false)
        .snapshots()
        .map((snap) => snap.docs.map((d) => UserSession.fromFirestore(d)).toList());
  }

  /// Revokes a specific session
  Future<void> revokeSession(String sessionId) async {
    await _firestore.collection('userSessions').doc(sessionId).update({'revoked': true});
  }

  /// Revokes all other sessions except current
  Future<void> revokeOtherSessions(String uid) async {
    final query = await _firestore
        .collection('userSessions')
        .where('uid', isEqualTo: uid)
        .where('revoked', isEqualTo: false)
        .get();

    final batch = _firestore.batch();
    for (final doc in query.docs) {
      if (doc.id != _currentSessionId) {
        batch.update(doc.reference, {'revoked': true});
      }
    }
    await batch.commit();
  }

  void dispose() {
    _heartbeatTimer?.cancel();
    _selfSessionSub?.cancel();
  }
}
