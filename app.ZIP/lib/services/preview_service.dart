import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/note_item.dart';

class PreviewService {
  /// Fetches rich URL preview metadata using microlink.io with failovers
  static Future<LinkPreviewData?> fetchLinkPreview(String rawUrl) async {
    String url = rawUrl.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://$url';
    }

    try {
      // Primary: Microlink API
      final uri = Uri.parse('https://api.microlink.io?url=${Uri.encodeComponent(url)}');
      final res = await http.get(uri).timeout(const Duration(seconds: 6));

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        if (json['status'] == 'success' && json['data'] != null) {
          final data = json['data'];
          return LinkPreviewData(
            title: data['title'] as String?,
            description: data['description'] as String?,
            image: data['image']?['url'] as String?,
            logo: data['logo']?['url'] as String?,
            site: data['publisher'] as String?,
          );
        }
      }
    } catch (_) {
      // Fallback
    }

    // Fallback: WordPress mshots screenshot + basic host
    try {
      final host = Uri.parse(url).host;
      return LinkPreviewData(
        title: host,
        description: url,
        image: 'https://s0.wp.com/mshots/v1/${Uri.encodeComponent(url)}?w=600',
        site: host,
      );
    } catch (_) {
      return null;
    }
  }
}
