import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'package:pointycastle/key_derivators/pbkdf2.dart';
import 'package:pointycastle/macs/hmac.dart';
import 'package:pointycastle/digests/sha256.dart';
import 'package:pointycastle/pointycastle.dart';
import '../core/constants.dart';

class AppLockService {
  final _secureStorage = const FlutterSecureStorage();
  final _localAuth = LocalAuthentication();

  int _failedAttempts = 0;
  DateTime? _lockoutUntil;

  DateTime? get lockoutUntil => _lockoutUntil;
  bool get isLockedOut => _lockoutUntil != null && DateTime.now().isBefore(_lockoutUntil!);

  /// Generates a random cryptographic salt
  Uint8List _generateSalt([int length = AppConstants.saltBytes]) {
    final random = Random.secure();
    return Uint8List.fromList(List<int>.generate(length, (_) => random.nextInt(256)));
  }

  /// Hashes a PIN using PBKDF2-SHA256 with 150,000 iterations
  String hashPin(String pin, Uint8List salt) {
    final pbkdf2 = PBKDF2KeyDerivator(HMac(SHA256Digest(), 64))
      ..init(Pbkdf2Parameters(salt, AppConstants.pbkdf2Iterations, 32));
    final key = pbkdf2.process(Uint8List.fromList(utf8.encode(pin)));
    return base64Encode(key);
  }

  /// Sets up a new App Lock PIN and stores it in secure storage
  Future<void> setPin(String pin, {bool enableBiometrics = true}) async {
    final salt = _generateSalt();
    final hash = hashPin(pin, salt);

    final lockData = {
      'salt': base64Encode(salt),
      'iter': AppConstants.pbkdf2Iterations,
      'hash': hash,
      'biometrics': enableBiometrics,
    };

    await _secureStorage.write(
      key: AppConstants.appLockKey,
      value: jsonEncode(lockData),
    );
  }

  /// Checks if App Lock is enabled
  Future<bool> isAppLockEnabled() async {
    final raw = await _secureStorage.read(key: AppConstants.appLockKey);
    return raw != null && raw.isNotEmpty;
  }

  /// Validates the entered PIN
  Future<bool> verifyPin(String pin) async {
    if (isLockedOut) return false;

    final raw = await _secureStorage.read(key: AppConstants.appLockKey);
    if (raw == null) return true;

    final data = jsonDecode(raw) as Map<String, dynamic>;
    final salt = base64Decode(data['salt'] as String);
    final expectedHash = data['hash'] as String;

    final calculatedHash = hashPin(pin, salt);
    if (calculatedHash == expectedHash) {
      _failedAttempts = 0;
      _lockoutUntil = null;
      return true;
    } else {
      _failedAttempts++;
      _applyExponentialBackoff();
      return false;
    }
  }

  void _applyExponentialBackoff() {
    if (_failedAttempts >= 5) {
      // 5 fails -> 30s, doubles each time up to 15 min
      final multiplier = pow(2, _failedAttempts - 5).toInt();
      final seconds = (30 * multiplier).clamp(30, 900);
      _lockoutUntil = DateTime.now().add(Duration(seconds: seconds));
    }
  }

  /// Attempts biometric authentication
  Future<bool> authenticateBiometric() async {
    if (isLockedOut) return false;

    final canCheck = await _localAuth.canCheckBiometrics;
    final isDeviceSupported = await _localAuth.isDeviceSupported();
    if (!canCheck || !isDeviceSupported) return false;

    try {
      final success = await _localAuth.authenticate(
        localizedReason: 'Scan fingerprint or Face ID to unlock MART Drive',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: true,
        ),
      );
      if (success) {
        _failedAttempts = 0;
        _lockoutUntil = null;
      }
      return success;
    } catch (_) {
      return false;
    }
  }

  /// Clears app lock (e.g. after Google account re-verification)
  Future<void> removeLock() async {
    await _secureStorage.delete(key: AppConstants.appLockKey);
    _failedAttempts = 0;
    _lockoutUntil = null;
  }
}
