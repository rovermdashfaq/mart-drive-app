import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../models/notification.dart';

class NotificationService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();

  final Set<String> _sessionAckedNoticeIds = {};

  bool isAcknowledgedInSession(String id) => _sessionAckedNoticeIds.contains(id);

  /// Initializes local notifications and FCM message handlers
  Future<void> initialize({required Function(String? payload) onSelectNotification}) async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings();
    const settings = InitializationSettings(android: androidSettings, iOS: iosSettings);

    await _localNotifications.initialize(
      settings,
      onDidReceiveNotificationResponse: (response) {
        onSelectNotification(response.payload);
      },
    );

    // Foreground message handler
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      final noticeId = message.data['noticeId'];
      // Skip if it carries noticeId (handled by Firestore listener)
      if (noticeId != null && noticeId.toString().isNotEmpty) {
        return;
      }

      final notification = message.notification;
      if (notification != null) {
        showLocalNotification(
          id: message.hashCode,
          title: notification.title ?? 'MART Drive',
          body: notification.body ?? '',
          payload: message.data['route'],
        );
      }
    });
  }

  /// Registers FCM Token into fcmTokens/{token}
  Future<void> registerFcmToken({required String email, required String uid}) async {
    try {
      final token = await _fcm.getToken();
      if (token != null) {
        await _firestore.collection('fcmTokens').doc(token).set({
          'token': token,
          'email': email.toLowerCase(),
          'uid': uid,
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
    } catch (_) {}
  }

  /// Displays an in-app local notification banner
  Future<void> showLocalNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'mart_drive_channel',
      'MART Drive Notifications',
      importance: Importance.max,
      priority: Priority.high,
    );
    const iosDetails = DarwinNotificationDetails();
    const details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    await _localNotifications.show(id, title, body, details, payload: payload);
  }

  /// Acknowledges an in-app warning notice modal
  Future<void> acknowledgeWarning(String notificationId) async {
    _sessionAckedNoticeIds.add(notificationId);
    await _firestore.collection('notifications').doc(notificationId).update({
      'read': true,
      'ackAt': FieldValue.serverTimestamp(),
    });
  }

  /// Stream of user notifications
  Stream<List<AppNotification>> streamNotifications(String email) {
    return _firestore
        .collection('notifications')
        .where('toEmail', isEqualTo: email.toLowerCase())
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => AppNotification.fromFirestore(d)).toList());
  }

  /// Mark all notifications as read
  Future<void> markAllAsRead(String email) async {
    final snap = await _firestore
        .collection('notifications')
        .where('toEmail', isEqualTo: email.toLowerCase())
        .where('read', isEqualTo: false)
        .get();

    final batch = _firestore.batch();
    for (final doc in snap.docs) {
      batch.update(doc.reference, {'read': true});
    }
    await batch.commit();
  }

  /// Delete notification
  Future<void> deleteNotification(String id) async {
    await _firestore.collection('notifications').doc(id).delete();
  }
}
