import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/file_item.dart';
import '../models/folder_item.dart';
import '../models/note_item.dart';
import '../models/organization.dart';
import '../models/user_profile.dart';
import '../models/share.dart';
import '../models/guest_request.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  FirestoreService() {
    // Enable offline persistence settings
    _firestore.settings = const Settings(
      persistenceEnabled: true,
      cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
    );
  }

  // USER PROFILE
  Stream<UserProfile?> streamUserProfile(String uid) {
    return _firestore.collection('users').doc(uid).snapshots().map((doc) {
      if (!doc.exists) return null;
      return UserProfile.fromFirestore(doc);
    });
  }

  Future<void> saveUserProfile(UserProfile profile) async {
    await _firestore.collection('users').doc(profile.uid).set(
      profile.toFirestore(),
      SetOptions(merge: true),
    );
  }

  // ORGANIZATIONS
  Stream<List<Organization>> streamUserOrganizations(String email) {
    return _firestore
        .collection('organizations')
        .where('members', arrayContains: email.toLowerCase())
        .snapshots()
        .map((snap) => snap.docs.map((d) => Organization.fromFirestore(d)).toList());
  }

  Future<void> createOrganization(Organization org) async {
    await _firestore.collection('organizations').doc(org.id).set(org.toFirestore());
  }

  Future<void> updateOrganization(Organization org) async {
    await _firestore.collection('organizations').doc(org.id).update(org.toFirestore());
  }

  // FILES
  Stream<List<FileItem>> streamFiles({
    required String uid,
    required String email,
    String? orgId,
    String? folderId,
    bool includeVault = false,
  }) {
    Query query = _firestore.collection('files');

    if (orgId != null && orgId.isNotEmpty) {
      query = query.where('orgId', isEqualTo: orgId);
    } else {
      query = query.where('uid', isEqualTo: uid);
    }

    return query.snapshots().map((snap) {
      final list = snap.docs.map((d) => FileItem.fromFirestore(d)).toList();
      return list.where((f) {
        if (!includeVault && f.vault) return false;
        if (includeVault && !f.vault) return false;
        if (folderId != null) {
          return f.folderId == folderId;
        }
        return true;
      }).toList();
    });
  }

  Future<void> addFile(FileItem file) async {
    await _firestore.collection('files').doc(file.id).set(file.toFirestore());
  }

  Future<void> updateFile(FileItem file) async {
    await _firestore.collection('files').doc(file.id).update(file.toFirestore());
  }

  Future<void> toggleStarFile(String fileId, bool currentStarred) async {
    await _firestore.collection('files').doc(fileId).update({'starred': !currentStarred});
  }

  Future<void> trashFile(String fileId) async {
    await _firestore.collection('files').doc(fileId).update({
      'trashed': true,
      'trashedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> restoreFile(String fileId) async {
    await _firestore.collection('files').doc(fileId).update({
      'trashed': false,
      'trashedAt': FieldValue.delete(),
    });
  }

  Future<void> deleteFilePermanently(String fileId) async {
    await _firestore.collection('files').doc(fileId).delete();
  }

  // FOLDERS
  Stream<List<FolderItem>> streamFolders({
    required String uid,
    String? orgId,
    String? parentId,
    bool includeVault = false,
  }) {
    Query query = _firestore.collection('folders');

    if (orgId != null && orgId.isNotEmpty) {
      query = query.where('orgId', isEqualTo: orgId);
    } else {
      query = query.where('uid', isEqualTo: uid);
    }

    return query.snapshots().map((snap) {
      final list = snap.docs.map((d) => FolderItem.fromFirestore(d)).toList();
      return list.where((f) {
        if (!includeVault && f.vault) return false;
        if (includeVault && !f.vault) return false;
        if (parentId != null) {
          return f.parentId == parentId;
        }
        return true;
      }).toList();
    });
  }

  Future<void> addFolder(FolderItem folder) async {
    await _firestore.collection('folders').doc(folder.id).set(folder.toFirestore());
  }

  Future<void> updateFolder(FolderItem folder) async {
    await _firestore.collection('folders').doc(folder.id).update(folder.toFirestore());
  }

  Future<void> trashFolder(String folderId) async {
    await _firestore.collection('folders').doc(folderId).update({
      'trashed': true,
      'trashedAt': FieldValue.serverTimestamp(),
    });
  }

  // NOTES & LINKS
  Stream<List<NoteItem>> streamNotes({
    required String uid,
    String? orgId,
    bool includeVault = false,
  }) {
    Query query = _firestore.collection('notes');
    if (orgId != null && orgId.isNotEmpty) {
      query = query.where('orgId', isEqualTo: orgId);
    } else {
      query = query.where('uid', isEqualTo: uid);
    }

    return query.snapshots().map((snap) {
      final list = snap.docs.map((d) => NoteItem.fromFirestore(d)).toList();
      return list.where((n) {
        if (!includeVault && n.vault) return false;
        if (includeVault && !n.vault) return false;
        return true;
      }).toList();
    });
  }

  Future<void> addNote(NoteItem note) async {
    await _firestore.collection('notes').doc(note.id).set(note.toFirestore());
  }

  Future<void> updateNote(NoteItem note) async {
    await _firestore.collection('notes').doc(note.id).update(note.toFirestore());
  }

  Future<void> trashNote(String noteId) async {
    await _firestore.collection('notes').doc(noteId).update({'trashed': true});
  }

  // SHARED ITEMS
  Stream<List<ShareItem>> streamSharedByMe(String uid) {
    return _firestore
        .collection('shares')
        .where('ownerUid', isEqualTo: uid)
        .snapshots()
        .map((snap) => snap.docs.map((d) => ShareItem.fromFirestore(d)).toList());
  }

  Stream<List<ShareItem>> streamSharedFromMe(String email) {
    return _firestore
        .collection('shares')
        .where('email', isEqualTo: email.toLowerCase())
        .snapshots()
        .map((snap) => snap.docs.map((d) => ShareItem.fromFirestore(d)).toList());
  }

  // JOIN REQUESTS
  Stream<List<JoinRequest>> streamJoinRequests(String orgId) {
    return _firestore
        .collection('joinRequests')
        .where('orgId', isEqualTo: orgId)
        .where('status', isEqualTo: 'pending')
        .snapshots()
        .map((snap) => snap.docs.map((d) => JoinRequest.fromFirestore(d)).toList());
  }

  Future<void> resolveJoinRequest(String requestId, bool approve, Organization org, String email) async {
    final status = approve ? 'approved' : 'rejected';
    await _firestore.collection('joinRequests').doc(requestId).update({'status': status});

    if (approve) {
      final members = List<String>.from(org.members);
      if (!members.contains(email.toLowerCase())) {
        members.add(email.toLowerCase());
        await _firestore.collection('organizations').doc(org.id).update({'members': members});
      }
    }
  }
}
