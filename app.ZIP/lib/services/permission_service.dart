import '../core/constants.dart';
import '../models/organization.dart';

enum UserRole {
  reader(1),
  commenter(2),
  writer(3);

  final int level;
  const UserRole(this.level);

  static UserRole fromString(String val) {
    switch (val.toLowerCase()) {
      case 'writer':
      case 'editor':
        return UserRole.writer;
      case 'commenter':
        return UserRole.commenter;
      default:
        return UserRole.reader;
    }
  }

  bool isAtLeast(UserRole other) => level >= other.level;
}

class PermissionService {
  /// Computes the active role of the current user on a file, folder or note.
  static UserRole roleOf({
    required dynamic item, // FileItem | FolderItem | NoteItem
    required String currentUid,
    required String currentEmail,
    Organization? org,
    Map<String, String>? joinsMap, // itemId -> role
  }) {
    final lowerEmail = currentEmail.toLowerCase();

    // 1. Creator is always writer
    if (item.uid == currentUid) {
      return UserRole.writer;
    }

    // 2. Organization founder or owner is writer
    if (org != null) {
      if (org.isOwner(lowerEmail) || org.isFounder(lowerEmail)) {
        return UserRole.writer;
      }
    }

    UserRole highest = UserRole.reader;

    // 3. Check ACL on the item
    final acl = (item.acl as List<dynamic>?);
    if (acl != null) {
      for (final entry in acl) {
        if (entry.email.toString().toLowerCase() == lowerEmail) {
          final entryRole = UserRole.fromString(entry.role.toString());
          if (entryRole.level > highest.level) {
            highest = entryRole;
          }
        }
      }
    }

    // 4. Check folderJoins / fileJoins
    if (joinsMap != null && joinsMap.containsKey(item.id)) {
      final joinRole = UserRole.fromString(joinsMap[item.id]!);
      if (joinRole.level > highest.level) {
        highest = joinRole;
      }
    }

    return highest;
  }

  /// Calculates available menu options based on user role and context
  static List<String> menuFor({
    required String kind, // 'file' | 'folder' | 'note' | 'sgroup' | 'sfrom'
    required dynamic item,
    required String currentUid,
    required String currentEmail,
    Organization? org,
    bool isVaultItem = false,
    bool isCustomOrder = false,
    bool isSearchActive = false,
    bool isExtMode = false,
  }) {
    final baseMenu = List<String>.from(AppConstants.menus[kind] ?? []);
    final role = roleOf(
      item: item,
      currentUid: currentUid,
      currentEmail: currentEmail,
      org: org,
    );

    final isOwnerOrAdmin = org != null && (org.isOwner(currentEmail) || org.isFounder(currentEmail));
    final isCreator = item.uid == currentUid;

    final filtered = <String>[];

    for (final action in baseMenu) {
      // Vault rule: context menu hides share/access/stopall while in vault
      if (isVaultItem && (action == 'share' || action == 'access' || action == 'stopall')) {
        continue;
      }

      // Reorder (up/down): ONLY org owner + custom order view + no search + not in extMode
      if (action == 'up' || action == 'down') {
        if (isOwnerOrAdmin && isCustomOrder && !isSearchActive && !isExtMode) {
          filtered.add(action);
        }
        continue;
      }

      // Write actions: rename, move, trash, tag, icon
      if (['rename', 'move', 'trash', 'tag', 'icon'].contains(action)) {
        if (kind == 'folder') {
          // Special rule from PATCH-v2 #1:
          // A folder is manageable only by creator OR org owner OR role == writer
          if (isCreator || isOwnerOrAdmin || role == UserRole.writer) {
            filtered.add(action);
          }
        } else {
          if (role == UserRole.writer || isCreator) {
            filtered.add(action);
          }
        }
        continue;
      }

      // Access/Share on folders: owner or org admin
      if (kind == 'folder' && (action == 'access' || action == 'share')) {
        if (isCreator || isOwnerOrAdmin) {
          filtered.add(action);
        }
        continue;
      }

      // Copy: for files, creator/owner only; else allowed unless extMode
      if (action == 'copy') {
        if (kind == 'file') {
          if (isCreator || isOwnerOrAdmin) filtered.add(action);
        } else if (!isExtMode) {
          filtered.add(action);
        }
        continue;
      }

      // Default permission check
      filtered.add(action);
    }

    return filtered;
  }
}
