import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import '../core/constants.dart';

class ImgbbService {
  final Dio _dio = Dio();

  /// Uploads an image (File or base64) to ImgBB and returns the direct display URL
  Future<String?> uploadImage(File imageFile) async {
    try {
      final bytes = await imageFile.readAsBytes();
      final base64Image = base64Encode(bytes);

      final formData = FormData.fromMap({
        'key': AppConstants.imgbbApiKey,
        'image': base64Image,
      });

      final response = await _dio.post(
        AppConstants.imgbbUploadUrl,
        data: formData,
      );

      if (response.statusCode == 200) {
        final data = response.data;
        if (data != null && data['data'] != null) {
          return data['data']['url'] as String?;
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// Uploads image bytes directly to ImgBB
  Future<String?> uploadBytes(List<int> bytes) async {
    try {
      final base64Image = base64Encode(bytes);
      final formData = FormData.fromMap({
        'key': AppConstants.imgbbApiKey,
        'image': base64Image,
      });

      final response = await _dio.post(
        AppConstants.imgbbUploadUrl,
        data: formData,
      );

      if (response.statusCode == 200) {
        final data = response.data;
        if (data != null && data['data'] != null) {
          return data['data']['url'] as String?;
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }
}
