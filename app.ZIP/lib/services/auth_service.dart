import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import '../core/constants.dart';
import '../models/user_profile.dart';

class AuthService {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: [
      'email',
      AppConstants.driveScope,
    ],
  );
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();

  Stream<User?> get authStateChanges => _firebaseAuth.authStateChanges();
  User? get currentUser => _firebaseAuth.currentUser;

  /// Checks if the user email is blocked in blockedUsers/{email}
  Future<Map<String, dynamic>?> checkBlocked(String email) async {
    final doc = await _firestore.collection('blockedUsers').doc(email.toLowerCase()).get();
    if (doc.exists) {
      return doc.data();
    }
    return null;
  }

  /// Submits an appeal for a blocked user to supportTickets/{uid}
  Future<void> submitAppeal({
    required String uid,
    required String email,
    required String message,
  }) async {
    await _firestore.collection('supportTickets').doc(uid).set({
      'email': email.toLowerCase(),
      'uid': uid,
      'type': 'ban_appeal',
      'message': message,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Signs in using Google with the requested Drive scope
  Future<UserProfile?> signInWithGoogle({
    required Function(String reason) onBlocked,
  }) async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null;

    final email = googleUser.email.toLowerCase();

    // 1. Block check
    final blocked = await checkBlocked(email);
    if (blocked != null) {
      await _googleSignIn.signOut();
      onBlocked(blocked['reason'] as String? ?? 'Your account has been suspended by an administrator.');
      return null;
    }

    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final userCredential = await _firebaseAuth.signInWithCredential(credential);
    final user = userCredential.user;
    if (user == null) return null;

    // 2. Store Drive accessToken in secure storage with 55 min TTL
    if (googleAuth.accessToken != null) {
      final expiry = DateTime.now().add(AppConstants.tokenTtl).millisecondsSinceEpoch;
      await _secureStorage.write(key: 'drive_token', value: googleAuth.accessToken);
      await _secureStorage.write(key: 'drive_token_expiry', value: expiry.toString());
    }

    // 3. Register user profile with merge in users/{uid}
    final userDocRef = _firestore.collection('users').doc(user.uid);
    final userDoc = await userDocRef.get();
    final isFirstLogin = !userDoc.exists;

    await userDocRef.set({
      'uid': user.uid,
      'email': email,
      'name': user.displayName ?? googleUser.displayName ?? 'MART User',
      'photoURL': user.photoURL ?? googleUser.photoUrl,
      'provider': 'google',
      'lastLogin': FieldValue.serverTimestamp(),
      'loginCount': FieldValue.increment(1),
      if (isFirstLogin) 'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    // 4. Anomaly detection via ipwho.is
    _detectLoginAnomaly(user.uid, email, isFirstLogin);

    return UserProfile(
      uid: user.uid,
      email: email,
      name: user.displayName ?? 'MART User',
      photoURL: user.photoURL,
      provider: 'google',
    );
  }

  /// Detects abnormal login location or device change
  Future<void> _detectLoginAnomaly(String uid, String email, bool isFirstLogin) async {
    if (isFirstLogin) return;

    try {
      final res = await http.get(Uri.parse('https://ipwho.is/')).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final country = data['country'] as String? ?? 'Unknown';

        final deviceDoc = await _firestore.collection('loginDevices').doc(uid).get();
        if (deviceDoc.exists) {
          final prevCountry = deviceDoc.data()?['country'] as String?;
          if (prevCountry != null && prevCountry != country) {
            // New country anomaly detected
            await _firestore.collection('notifications').add({
              'toEmail': email,
              'toUid': uid,
              'type': 'login_anomaly',
              'title': 'New Login Location Detected',
              'body': 'Your account was accessed from $country (previously $prevCountry). If this was not you, review your active sessions immediately.',
              'read': false,
              'createdAt': FieldValue.serverTimestamp(),
            });
          }
        }

        await _firestore.collection('loginDevices').doc(uid).set({
          'uid': uid,
          'email': email,
          'country': country,
          'lastSeen': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
    } catch (_) {}
  }

  /// Retrieves the cached Google Drive access token, re-authenticating if expired
  Future<String?> getValidDriveToken() async {
    final token = await _secureStorage.read(key: 'drive_token');
    final expiryStr = await _secureStorage.read(key: 'drive_token_expiry');

    if (token != null && expiryStr != null) {
      final expiry = int.tryParse(expiryStr) ?? 0;
      if (DateTime.now().millisecondsSinceEpoch < expiry) {
        return token;
      }
    }

    // Attempt token refresh via GoogleSignIn
    try {
      final googleUser = await _googleSignIn.signInSilently();
      if (googleUser != null) {
        final auth = await googleUser.authentication;
        if (auth.accessToken != null) {
          final newExpiry = DateTime.now().add(AppConstants.tokenTtl).millisecondsSinceEpoch;
          await _secureStorage.write(key: 'drive_token', value: auth.accessToken);
          await _secureStorage.write(key: 'drive_token_expiry', value: newExpiry.toString());
          return auth.accessToken;
        }
      }
    } catch (_) {}

    return null;
  }

  /// Sign out
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _firebaseAuth.signOut();
    await _secureStorage.delete(key: 'drive_token');
    await _secureStorage.delete(key: 'drive_token_expiry');
  }
}
