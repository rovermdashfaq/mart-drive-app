import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

class DriveUploadProgress {
  final int sentBytes;
  final int totalBytes;
  double get fraction => totalBytes > 0 ? (sentBytes / totalBytes).clamp(0.0, 1.0) : 0.0;
  int get percentage => (fraction * 100).toInt();

  DriveUploadProgress({required this.sentBytes, required this.totalBytes});
}

class DriveService {
  final Dio _dio = Dio();

  static String getThumbnailUrl(String driveFileId, [int size = 1600]) {
    return 'https://drive.google.com/thumbnail?id=$driveFileId&sz=w$size';
  }

  /// Uploads a file to Google Drive using multipart upload
  Future<Map<String, dynamic>> uploadFileMultipart({
    required File file,
    required String fileName,
    required String mimeType,
    required String accessToken,
    void Function(DriveUploadProgress progress)? onProgress,
  }) async {
    const uploadUrl =
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size';

    final fileSize = await file.length();
    final metadata = {
      'name': fileName,
      'mimeType': mimeType,
    };

    final metadataJson = jsonEncode(metadata);
    const boundary = '-------314159265358979323846';
    const delimiter = '\r\n--$boundary\r\n';
    const closeDelimiter = '\r\n--$boundary--';

    final requestHeaders = {
      'Authorization': 'Bearer $accessToken',
      'Content-Type': 'multipart/related; boundary=$boundary',
    };

    final fileBytes = await file.readAsBytes();

    final bodyBytes = <int>[
      ...utf8.encode(delimiter),
      ...utf8.encode('Content-Type: application/json; charset=UTF-8\r\n\r\n'),
      ...utf8.encode(metadataJson),
      ...utf8.encode(delimiter),
      ...utf8.encode('Content-Type: $mimeType\r\n\r\n'),
      ...fileBytes,
      ...utf8.encode(closeDelimiter),
    ];

    final response = await _dio.post(
      uploadUrl,
      data: Stream.fromIterable([bodyBytes]),
      options: Options(
        headers: requestHeaders,
        contentType: 'multipart/related; boundary=$boundary',
      ),
      onSendProgress: (sent, total) {
        if (onProgress != null) {
          onProgress(DriveUploadProgress(sentBytes: sent, totalBytes: total));
        }
      },
    );

    return response.data as Map<String, dynamic>;
  }

  /// Grants public reader permission to the Drive file
  Future<void> makePublicReader({
    required String driveFileId,
    required String accessToken,
  }) async {
    final url = 'https://www.googleapis.com/drive/v3/files/$driveFileId/permissions';
    await _dio.post(
      url,
      data: {'role': 'reader', 'type': 'anyone'},
      options: Options(headers: {'Authorization': 'Bearer $accessToken'}),
    );
  }

  /// Grants member access (reader or writer)
  Future<void> grantMemberAccess({
    required String driveFileId,
    required String email,
    required String role, // 'reader' | 'writer'
    required String accessToken,
  }) async {
    final url = 'https://www.googleapis.com/drive/v3/files/$driveFileId/permissions';
    await _dio.post(
      url,
      data: {
        'role': role == 'writer' ? 'writer' : 'reader',
        'type': 'user',
        'emailAddress': email,
      },
      options: Options(headers: {'Authorization': 'Bearer $accessToken'}),
    );
  }

  /// Gets current user storage quota from Google Drive
  Future<Map<String, dynamic>> getStorageQuota(String accessToken) async {
    final url = 'https://www.googleapis.com/drive/v3/about?fields=storageQuota';
    final response = await _dio.get(
      url,
      options: Options(headers: {'Authorization': 'Bearer $accessToken'}),
    );
    return response.data['storageQuota'] as Map<String, dynamic>? ?? {};
  }

  /// Downloads file from Google Drive to local application storage
  Future<File> downloadFile({
    required String driveFileId,
    required String fileName,
    required String accessToken,
    void Function(int received, int total)? onProgress,
  }) async {
    final url = 'https://www.googleapis.com/drive/v3/files/$driveFileId?alt=media';
    final dir = await getApplicationDocumentsDirectory();
    final savePath = p.join(dir.path, fileName);

    await _dio.download(
      url,
      savePath,
      options: Options(headers: {'Authorization': 'Bearer $accessToken'}),
      onReceiveProgress: onProgress,
    );

    return File(savePath);
  }
}
