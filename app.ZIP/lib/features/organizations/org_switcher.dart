import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/auth_provider.dart';
import '../../models/organization.dart';
import '../../widgets/org_logo.dart';

class OrgSwitcher extends ConsumerWidget {
  final List<Organization> organizations;
  final VoidCallback onAddOrg;

  const OrgSwitcher({
    super.key,
    required this.organizations,
    required this.onAddOrg,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedOrg = ref.watch(selectedOrgProvider);
    final theme = Theme.of(context);

    return SizedBox(
      height: 48,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          // Personal Workspace Chip
          ChoiceChip(
            avatar: const OrgLogo(org: null, size: 24),
            label: const Text('Personal'),
            selected: selectedOrg == null,
            onSelected: (selected) {
              if (selected) ref.read(selectedOrgProvider.notifier).state = null;
            },
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
          const SizedBox(width: 8),

          // Organizations
          ...organizations.map((org) {
            final isSelected = selectedOrg?.id == org.id;

            return Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: ChoiceChip(
                avatar: OrgLogo(org: org, size: 24),
                label: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(org.name),
                    if (org.isPremium) ...[
                      const SizedBox(width: 4),
                      const Icon(Icons.workspace_premium_rounded, size: 14, color: Color(0xFFF59E0B)),
                    ],
                  ],
                ),
                selected: isSelected,
                onSelected: (selected) {
                  if (selected) ref.read(selectedOrgProvider.notifier).state = org;
                },
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              ),
            );
          }),

          // New Organization Button
          ActionChip(
            avatar: const Icon(Icons.add, size: 18),
            label: const Text('New Org'),
            onPressed: onAddOrg,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
        ],
      ),
    );
  }
}
