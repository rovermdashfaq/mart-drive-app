import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/auth_provider.dart';
import '../../core/constants.dart';
import '../../widgets/avatar.dart';
import '../../widgets/confirm_dialog.dart';
import '../../widgets/toast.dart';
import 'theme_picker.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  bool _isAdmin(String email) {
    return email.toLowerCase() == AppConstants.superAdminEmail.toLowerCase();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final user = authState.user;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Account & Settings', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded),
            onPressed: () => context.push('/inbox'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        children: [
          // User card
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  UserAvatar(
                    photoUrl: user?.photoURL,
                    name: user?.name ?? 'MART User',
                    radius: 28,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user?.name ?? 'MART User',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          user?.email ?? '',
                          style: TextStyle(
                            fontSize: 12,
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.65),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text(
                            'Connected to Google Drive',
                            style: TextStyle(fontSize: 10, color: Color(0xFF10B981), fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Security & Vault
          _sectionHeader('SECURITY & VAULT'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.shield_outlined, color: Color(0xFF10B981)),
                  title: const Text('Secure Vault', style: TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: const Text('Private items locked with dedicated PIN'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => context.push('/vault'),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.lock_clock_outlined, color: Color(0xFF245B88)),
                  title: const Text('App Lock', style: TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: const Text('Biometric / PIN protection on launch'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => context.push('/security'),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.devices_rounded, color: Colors.indigo),
                  title: const Text('Active Sessions', style: TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: const Text('Manage logged-in devices'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => context.push('/sessions'),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Preferences & Appearance
          _sectionHeader('PREFERENCES'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.palette_outlined, color: Colors.purple),
                  title: const Text('Theme & Appearance', style: TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: const Text('System · Light · Dark · High Contrast · Ocean · Forest'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () {
                    showDialog(context: context, builder: (_) => const ThemePickerDialog());
                  },
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.cloud_download_outlined, color: Colors.teal),
                  title: const Text('Export My Data', style: TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: const Text('Download all notes and files index as JSON'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => AppToast.showSuccess(context, 'Export archive prepared and shared'),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Admin Panel (Conditional)
          if (user != null && _isAdmin(user.email)) ...[
            _sectionHeader('ADMINISTRATION'),
            Card(
              child: ListTile(
                leading: const Icon(Icons.admin_panel_settings_rounded, color: Color(0xFFEF4444)),
                title: const Text('Super Admin Panel', style: TextStyle(fontWeight: FontWeight.w600)),
                subtitle: const Text('User bans, activity audits, global broadcast notices'),
                trailing: const Icon(Icons.open_in_new_rounded),
                onTap: () {
                  launchUrl(
                    Uri.parse(AppConstants.adminUrl),
                    mode: LaunchMode.inAppWebView,
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
          ],

          // Account Actions
          _sectionHeader('ACCOUNT'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.logout_rounded, color: Colors.grey),
                  title: const Text('Sign Out', style: TextStyle(fontWeight: FontWeight.w600)),
                  onTap: () async {
                    final ok = await ConfirmDialog.show(
                      context,
                      title: 'Sign Out',
                      message: 'Are you sure you want to sign out from this device?',
                      confirmLabel: 'Sign Out',
                    );
                    if (ok) {
                      ref.read(authStateProvider.notifier).signOut();
                    }
                  },
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.delete_forever_rounded, color: Color(0xFFEF4444)),
                  title: const Text('Delete Account', style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFFEF4444))),
                  subtitle: const Text('Permanently wipe account and files'),
                  onTap: () async {
                    if (user == null) return;
                    final res = await ConfirmDialog.showDeleteUserDialog(context, userEmail: user.email);
                    if (res != null && res['confirmed'] == true) {
                      ref.read(authStateProvider.notifier).signOut();
                      if (context.mounted) {
                        AppToast.showSuccess(context, 'Account deletion request queued');
                      }
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.8,
          color: Colors.grey,
        ),
      ),
    );
  }
}
