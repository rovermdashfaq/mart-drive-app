import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/auth_provider.dart';
import '../../core/theme.dart';

class ThemePickerDialog extends ConsumerWidget {
  const ThemePickerDialog({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentTheme = ref.watch(appThemeProvider);

    final themes = [
      {'mode': AppThemeMode.system, 'name': 'System', 'desc': 'Follow device settings', 'color': Colors.grey},
      {'mode': AppThemeMode.light, 'name': 'Light', 'desc': 'Clean crisp daytime', 'color': const Color(0xFFF7FAFD)},
      {'mode': AppThemeMode.dark, 'name': 'Dark', 'desc': 'OLED dark night', 'color': const Color(0xFF0F1A24)},
      {'mode': AppThemeMode.highContrast, 'name': 'High Contrast', 'desc': 'Maximum readability', 'color': Colors.black},
      {'mode': AppThemeMode.ocean, 'name': 'Ocean', 'desc': 'Deep marine blue', 'color': const Color(0xFF0F3057)},
      {'mode': AppThemeMode.forest, 'name': 'Forest', 'desc': 'Earthy pine green', 'color': const Color(0xFF1B4332)},
    ];

    return AlertDialog(
      title: const Text('Choose App Theme', style: TextStyle(fontWeight: FontWeight.bold)),
      content: SizedBox(
        width: double.maxFinite,
        child: ListView.separated(
          shrinkWrap: true,
          itemCount: themes.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final t = themes[index];
            final mode = t['mode'] as AppThemeMode;
            final isSelected = currentTheme == mode;

            return Card(
              color: isSelected ? Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3) : null,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(
                  color: isSelected ? Theme.of(context).colorScheme.primary : Colors.grey.shade300,
                  width: isSelected ? 2 : 1,
                ),
              ),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: t['color'] as Color,
                  radius: 14,
                ),
                title: Text(t['name'] as String, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text(t['desc'] as String, style: const TextStyle(fontSize: 11)),
                trailing: isSelected ? Icon(Icons.check_circle_rounded, color: Theme.of(context).colorScheme.primary) : null,
                onTap: () {
                  ref.read(appThemeProvider.notifier).state = mode;
                  Navigator.pop(context);
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
