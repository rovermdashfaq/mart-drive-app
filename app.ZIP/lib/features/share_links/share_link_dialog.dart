import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants.dart';
import '../../widgets/toast.dart';

class ShareLinkDialog extends StatefulWidget {
  final String itemId;
  final String itemName;
  final bool isFolder;
  final bool isOrgOwner;

  const ShareLinkDialog({
    super.key,
    required this.itemId,
    required this.itemName,
    this.isFolder = false,
    this.isOrgOwner = false,
  });

  @override
  State<ShareLinkDialog> createState() => _ShareLinkDialogState();
}

class _ShareLinkDialogState extends State<ShareLinkDialog> {
  String _selectedRole = 'Viewer';
  String _selectedExpiry = 'Never';
  final TextEditingController _passwordController = TextEditingController();
  bool _enablePassword = false;
  String? _generatedLink;

  void _generateLink() {
    // Role string
    final role = _selectedRole.toLowerCase() == 'editor' ? 'writer' : _selectedRole.toLowerCase();

    // Deep link scheme: martdrive://file/{id}_{role}
    // Web link fallback: https://mart-drive.vercel.app/file/{id}_{role}
    final link = '${AppConstants.webAppUrl}/${widget.isFolder ? "fshare" : "file"}/${widget.itemId}_$role';

    setState(() => _generatedLink = link);
  }

  @override
  Widget build(BuildContext context) {
    // PATCH-v2 #2: Members (not owner) may only create Viewer/Commenter folder links
    final roleOptions = (widget.isFolder && !widget.isOrgOwner)
        ? ['Viewer', 'Commenter']
        : ['Viewer', 'Commenter', 'Editor'];

    return AlertDialog(
      title: Text('Share "${widget.itemName}"', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Access Permissions', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            DropdownButtonFormField<String>(
              value: _selectedRole,
              items: roleOptions.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
              onChanged: (val) {
                if (val != null) {
                  setState(() {
                    _selectedRole = val;
                    _generateLink();
                  });
                }
              },
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            const Text('Link Expiration', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            DropdownButtonFormField<String>(
              value: _selectedExpiry,
              items: ['Never', '1 day', '7 days', '30 days']
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (val) {
                if (val != null) setState(() => _selectedExpiry = val);
              },
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Require Password'),
              value: _enablePassword,
              onChanged: (val) => setState(() => _enablePassword = val ?? false),
            ),
            if (_enablePassword)
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Access Password',
                  border: OutlineInputBorder(),
                ),
              ),

            if (_generatedLink != null) ...[
              const SizedBox(height: 16),
              Center(
                child: QrImageView(
                  data: _generatedLink!,
                  version: QrVersions.auto,
                  size: 160.0,
                  embeddedImage: const NetworkImage(AppConstants.logoUrl),
                  embeddedImageStyle: const QrEmbeddedImageStyle(size: Size(24, 24)),
                ),
              ),
              const SizedBox(height: 12),
              SelectableText(
                _generatedLink!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Colors.blue),
              ),
            ],
          ],
        ),
      ),
      actions: [
        if (_generatedLink != null) ...[
          IconButton(
            icon: const Icon(Icons.copy_rounded),
            tooltip: 'Copy Link',
            onPressed: () {
              Clipboard.setData(ClipboardData(text: _generatedLink!));
              AppToast.showSuccess(context, 'Link copied to clipboard');
            },
          ),
          IconButton(
            icon: const Icon(Icons.share_rounded),
            tooltip: 'Share',
            onPressed: () => Share.share(_generatedLink!),
          ),
        ],
        FilledButton(
          onPressed: _generateLink,
          child: Text(_generatedLink == null ? 'Generate Link & QR' : 'Done'),
        ),
      ],
    );
  }
}
