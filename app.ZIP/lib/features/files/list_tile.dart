import 'package:flutter/material.dart';
import '../../models/file_item.dart';
import '../../utils/drive_helper.dart';
import '../../utils/formatters.dart';

class FileListTile extends StatelessWidget {
  final FileItem file;
  final bool isSelected;
  final bool isSelectionMode;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final VoidCallback onStarToggle;
  final VoidCallback onMenuTap;

  const FileListTile({
    super.key,
    required this.file,
    this.isSelected = false,
    this.isSelectionMode = false,
    required this.onTap,
    required this.onLongPress,
    required this.onStarToggle,
    required this.onMenuTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: isSelected ? theme.colorScheme.primaryContainer.withValues(alpha: 0.3) : theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected ? theme.colorScheme.primary : theme.colorScheme.outlineVariant.withValues(alpha: 0.5),
        ),
      ),
      child: ListTile(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onTap: onTap,
        onLongPress: onLongPress,
        leading: isSelectionMode
            ? Icon(
                isSelected ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                color: isSelected ? theme.colorScheme.primary : Colors.grey,
              )
            : Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(DriveHelper.getIconForMime(file.mimeType), color: theme.colorScheme.primary),
              ),
        title: Text(
          file.name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        ),
        subtitle: Text(
          '${AppFormatters.fmtSize(file.size)} · ${AppFormatters.ago(file.createdAt)}',
          style: TextStyle(fontSize: 12, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(
                file.starred ? Icons.star_rounded : Icons.star_border_rounded,
                color: file.starred ? const Color(0xFFF59E0B) : Colors.grey,
                size: 20,
              ),
              onPressed: onStarToggle,
            ),
            IconButton(
              icon: const Icon(Icons.more_vert_rounded, size: 20),
              onPressed: onMenuTap,
            ),
          ],
        ),
      ),
    );
  }
}
