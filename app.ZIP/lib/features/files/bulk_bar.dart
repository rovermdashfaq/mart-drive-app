import 'package:flutter/material.dart';

class BulkActionBar extends StatelessWidget {
  final int selectedCount;
  final VoidCallback onClear;
  final VoidCallback onStar;
  final VoidCallback onDownload;
  final VoidCallback onRename;
  final VoidCallback onMove;
  final VoidCallback onTrash;

  const BulkActionBar({
    super.key,
    required this.selectedCount,
    required this.onClear,
    required this.onStar,
    required this.onDownload,
    required this.onRename,
    required this.onMove,
    required this.onTrash,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.15),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: onClear,
            tooltip: 'Cancel selection',
          ),
          Text(
            '$selectedCount selected',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.star_border_rounded),
            onPressed: onStar,
            tooltip: 'Star',
          ),
          IconButton(
            icon: const Icon(Icons.download_rounded),
            onPressed: onDownload,
            tooltip: 'Download',
          ),
          if (selectedCount == 1)
            IconButton(
              icon: const Icon(Icons.drive_file_rename_outline_rounded),
              onPressed: onRename,
              tooltip: 'Rename',
            ),
          IconButton(
            icon: const Icon(Icons.drive_file_move_outlined),
            onPressed: onMove,
            tooltip: 'Move',
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded, color: Color(0xFFEF4444)),
            onPressed: onTrash,
            tooltip: 'Trash',
          ),
        ],
      ),
    );
  }
}
