import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/auth_provider.dart';
import '../../models/organization.dart';
import '../../models/folder_item.dart';
import '../../models/file_item.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/toast.dart';
import '../organizations/org_switcher.dart';
import 'file_card.dart';

class DriveScreen extends ConsumerStatefulWidget {
  const DriveScreen({super.key});

  @override
  ConsumerState<DriveScreen> createState() => _DriveScreenState();
}

class _DriveScreenState extends ConsumerState<DriveScreen> {
  final List<FolderItem> _breadcrumbs = [];

  @override
  Widget build(BuildContext context) {
    final selectedOrg = ref.watch(selectedOrgProvider);
    final authState = ref.watch(authStateProvider);
    final theme = Theme.of(context);

    // Sample organizations
    final sampleOrgs = [
      Organization(
        id: 'org_mart_core',
        name: 'MART Engineering',
        teamName: 'Mobile & Cloud',
        owner: authState.user?.uid ?? 'user_1',
        ownerEmail: authState.user?.email ?? 'team@mart.com',
        founders: [authState.user?.email ?? 'team@mart.com'],
        owners: [authState.user?.email ?? 'team@mart.com'],
        members: List.generate(12, (i) => 'member$i@mart.com'), // 12 members -> triggers premium look!
        premiumLook: true,
      ),
    ];

    // Sample folders
    final sampleFolders = [
      FolderItem(
        id: 'f1',
        name: 'Design Assets',
        uid: authState.user?.uid ?? '',
        createdAt: DateTime.now().subtract(const Duration(days: 4)),
      ),
      FolderItem(
        id: 'f2',
        name: 'Contracts & Legal',
        uid: authState.user?.uid ?? '',
        createdAt: DateTime.now().subtract(const Duration(days: 10)),
      ),
      FolderItem(
        id: 'f3',
        name: 'Marketing Campaigns',
        uid: authState.user?.uid ?? '',
        createdAt: DateTime.now().subtract(const Duration(days: 15)),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          selectedOrg?.name ?? 'My Drive',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          if (selectedOrg != null && selectedOrg.isOwner(authState.user?.email ?? ''))
            IconButton(
              icon: const Icon(Icons.group_add_outlined),
              tooltip: 'Join Requests',
              onPressed: () => context.push('/org/join-requests'),
            ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            tooltip: 'Trash',
            onPressed: () => context.push('/trash'),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'Manage Org',
            onPressed: () {
              if (selectedOrg != null) {
                context.push('/org/manage');
              } else {
                AppToast.showSuccess(context, 'Personal workspace settings in Profile');
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Org switcher
          OrgSwitcher(
            organizations: sampleOrgs,
            onAddOrg: () => context.push('/org/create'),
          ),

          // Storage quota banner
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5)),
            ),
            child: Row(
              children: [
                const Icon(Icons.cloud_done_rounded, color: Color(0xFF10B981)),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Cloud Storage',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                      ),
                      Text(
                        '2.4 GB of 15 GB used · Google Drive',
                        style: TextStyle(fontSize: 11, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: () => context.push('/profile/storage'),
                  child: const Text('Details', style: TextStyle(fontSize: 12)),
                ),
              ],
            ),
          ),

          // Breadcrumbs
          if (_breadcrumbs.isNotEmpty)
            SizedBox(
              height: 36,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _breadcrumbs.length + 1,
                separatorBuilder: (_, __) => const Icon(Icons.chevron_right, size: 16, color: Colors.grey),
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return InkWell(
                      onTap: () => setState(() => _breadcrumbs.clear()),
                      child: const Center(
                        child: Text(
                          'Root',
                          style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF245B88)),
                        ),
                      ),
                    );
                  }
                  final folder = _breadcrumbs[index - 1];
                  return Center(
                    child: Text(
                      folder.name,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  );
                },
              ),
            ),

          const Divider(height: 1),

          // Folder cards & file content
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                  'Folders',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
                const SizedBox(height: 10),
                ...sampleFolders.map((folder) {
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: const Icon(Icons.folder_rounded, color: Color(0xFF245B88), size: 32),
                      title: Text(folder.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: const Text('3 items · Updated recently', style: TextStyle(fontSize: 11)),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => setState(() => _breadcrumbs.add(folder)),
                    ),
                  );
                }),
                const SizedBox(height: 16),
                const Text(
                  'Files in this folder',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
                const SizedBox(height: 10),
                EmptyStateWidget.forView('drive', onAction: () => context.push('/upload')),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => context.push('/upload'),
        child: const Icon(Icons.file_upload_outlined),
      ),
    );
  }
}
