import 'package:flutter/material.dart';
import '../../services/permission_service.dart';

class FileContextMenu {
  static Future<String?> show(
    BuildContext context, {
    required String kind,
    required dynamic item,
    required String currentUid,
    required String currentEmail,
    bool isVaultItem = false,
  }) {
    final allowedActions = PermissionService.menuFor(
      kind: kind,
      item: item,
      currentUid: currentUid,
      currentEmail: currentEmail,
      isVaultItem: isVaultItem,
    );

    final actionLabels = {
      'open': {'icon': Icons.open_in_new_rounded, 'label': 'Open'},
      'star': {'icon': Icons.star_border_rounded, 'label': item.starred ? 'Unstar' : 'Star'},
      'share': {'icon': Icons.share_rounded, 'label': 'Share link'},
      'access': {'icon': Icons.manage_accounts_rounded, 'label': 'Manage access'},
      'download': {'icon': Icons.download_rounded, 'label': 'Download'},
      'rename': {'icon': Icons.edit_outlined, 'label': 'Rename'},
      'move': {'icon': Icons.drive_file_move_outlined, 'label': 'Move to...'},
      'copy': {'icon': Icons.copy_rounded, 'label': 'Make a copy'},
      'copytext': {'icon': Icons.content_copy_rounded, 'label': 'Copy text'},
      'tag': {'icon': Icons.label_outline_rounded, 'label': 'Tags'},
      'icon': {'icon': Icons.palette_outlined, 'label': 'Change color/icon'},
      'up': {'icon': Icons.arrow_upward_rounded, 'label': 'Move up'},
      'down': {'icon': Icons.arrow_downward_rounded, 'label': 'Move down'},
      'info': {'icon': Icons.info_outline_rounded, 'label': 'Details & activity'},
      'trash': {'icon': Icons.delete_outline_rounded, 'label': 'Move to trash', 'color': const Color(0xFFEF4444)},
      'stopall': {'icon': Icons.block_flipped, 'label': 'Stop sharing with all', 'color': const Color(0xFFEF4444)},
    };

    return showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 12),
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.withValues(alpha: 0.4),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              child: Text(
                item.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
            const Divider(),
            Expanded(
              child: ListView(
                children: allowedActions.map((action) {
                  final meta = actionLabels[action];
                  if (meta == null) return const SizedBox.shrink();

                  final icon = meta['icon'] as IconData;
                  final label = meta['label'] as String;
                  final color = meta['color'] as Color?;

                  return ListTile(
                    leading: Icon(icon, color: color ?? Theme.of(context).colorScheme.onSurface),
                    title: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w500)),
                    onTap: () => Navigator.pop(ctx, action),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
