import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/auth_provider.dart';
import '../../models/file_item.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/toast.dart';
import '../../widgets/undo_toast.dart';
import 'file_card.dart';
import 'list_tile.dart';
import 'bulk_bar.dart';
import 'context_menu.dart';

class AllFilesScreen extends ConsumerStatefulWidget {
  const AllFilesScreen({super.key});

  @override
  ConsumerState<AllFilesScreen> createState() => _AllFilesScreenState();
}

class _AllFilesScreenState extends ConsumerState<AllFilesScreen> {
  String _selectedSegment = 'All'; // All · Files · Folders · Notes · Links · Starred · Recent
  bool _isGridView = true;
  String _sortOption = 'Last modified'; // Last modified / Newest / Name / Size
  final Set<String> _selectedIds = {};

  final List<String> _segments = [
    'All',
    'Files',
    'Folders',
    'Notes',
    'Links',
    'Starred',
    'Recent'
  ];

  void _toggleSelection(String id) {
    setState(() {
      if (_selectedIds.contains(id)) {
        _selectedIds.remove(id);
      } else {
        _selectedIds.add(id);
      }
    });
  }

  void _clearSelection() {
    setState(() => _selectedIds.clear());
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authStateProvider);
    final theme = Theme.of(context);
    final isSelectionMode = _selectedIds.isNotEmpty;

    // Sample/demo items connecting with the backend models
    final sampleFiles = [
      FileItem(
        id: 'file_demo_1',
        driveFileId: '1abc_design_system_preview',
        name: 'Brand Guidelines 2026.pdf',
        mimeType: 'application/pdf',
        size: 3450000,
        uid: authState.user?.uid ?? 'user_1',
        starred: true,
        createdAt: DateTime.now().subtract(const Duration(hours: 3)),
      ),
      FileItem(
        id: 'file_demo_2',
        driveFileId: '2xyz_product_shot',
        name: 'Quarterly_Report_Q4.xlsx',
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        size: 1240000,
        uid: authState.user?.uid ?? 'user_1',
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
      ),
      FileItem(
        id: 'file_demo_3',
        driveFileId: '3uvw_hero_image',
        name: 'Workspace_Mockup.png',
        mimeType: 'image/png',
        thumb: 'https://i.ibb.co/zhhYdVdD/Picsart-26-10-26-09-26-17-563.jpg',
        size: 4200000,
        uid: authState.user?.uid ?? 'user_1',
        starred: false,
        createdAt: DateTime.now().subtract(const Duration(days: 2)),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('MART Drive', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () => context.push('/search'),
          ),
          IconButton(
            icon: Icon(_isGridView ? Icons.view_list_rounded : Icons.grid_view_rounded),
            onPressed: () => setState(() => _isGridView = !_isGridView),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort_rounded),
            initialValue: _sortOption,
            onSelected: (val) => setState(() => _sortOption = val),
            itemBuilder: (_) => [
              'Last modified',
              'Newest',
              'Name',
              'Size',
              'Custom order'
            ].map((s) => PopupMenuItem(value: s, child: Text(s))).toList(),
          ),
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // Segment Chips
              SizedBox(
                height: 48,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  scrollDirection: Axis.horizontal,
                  itemCount: _segments.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final seg = _segments[index];
                    final isSelected = _selectedSegment == seg;
                    return FilterChip(
                      selected: isSelected,
                      label: Text(seg),
                      onSelected: (_) => setState(() => _selectedSegment = seg),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    );
                  },
                ),
              ),

              const SizedBox(height: 8),

              // Files Grid / List
              Expanded(
                child: RefreshIndicator(
                  onRefresh: () async {
                    await Future.delayed(const Duration(milliseconds: 600));
                    if (mounted) AppToast.showSuccess(context, 'Synced with MART Drive cloud');
                  },
                  child: sampleFiles.isEmpty
                      ? EmptyStateWidget.forView('all')
                      : _isGridView
                          ? GridView.builder(
                              padding: const EdgeInsets.all(16),
                              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 12,
                                mainAxisSpacing: 12,
                                childAspectRatio: 0.85,
                              ),
                              itemCount: sampleFiles.length,
                              itemBuilder: (context, index) {
                                final file = sampleFiles[index];
                                final isSelected = _selectedIds.contains(file.id);

                                return FileCard(
                                  file: file,
                                  isSelected: isSelected,
                                  isSelectionMode: isSelectionMode,
                                  onTap: () {
                                    if (isSelectionMode) {
                                      _toggleSelection(file.id);
                                    } else {
                                      context.push('/preview/${file.id}');
                                    }
                                  },
                                  onLongPress: () => _toggleSelection(file.id),
                                  onStarToggle: () {
                                    AppToast.showSuccess(context, file.starred ? 'Removed from starred' : 'Added to starred');
                                  },
                                  onMenuTap: () async {
                                    final action = await FileContextMenu.show(
                                      context,
                                      kind: 'file',
                                      item: file,
                                      currentUid: authState.user?.uid ?? '',
                                      currentEmail: authState.user?.email ?? '',
                                    );
                                    if (action == 'trash' && context.mounted) {
                                      UndoToast.show(
                                        context: context,
                                        message: 'Moved "${file.name}" to trash',
                                        onUndo: () => AppToast.showSuccess(context, 'Restored "${file.name}"'),
                                      );
                                    }
                                  },
                                );
                              },
                            )
                          : ListView.separated(
                              padding: const EdgeInsets.all(16),
                              itemCount: sampleFiles.length,
                              separatorBuilder: (_, __) => const SizedBox(height: 8),
                              itemBuilder: (context, index) {
                                final file = sampleFiles[index];
                                final isSelected = _selectedIds.contains(file.id);

                                return FileListTile(
                                  file: file,
                                  isSelected: isSelected,
                                  isSelectionMode: isSelectionMode,
                                  onTap: () {
                                    if (isSelectionMode) {
                                      _toggleSelection(file.id);
                                    } else {
                                      context.push('/preview/${file.id}');
                                    }
                                  },
                                  onLongPress: () => _toggleSelection(file.id),
                                  onStarToggle: () {},
                                  onMenuTap: () {},
                                );
                              },
                            ),
                ),
              ),
            ],
          ),

          // Floating Bulk Action Bar
          if (isSelectionMode)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: BulkActionBar(
                selectedCount: _selectedIds.length,
                onClear: _clearSelection,
                onStar: () {
                  AppToast.showSuccess(context, 'Starred ${_selectedIds.length} items');
                  _clearSelection();
                },
                onDownload: () {
                  AppToast.showSuccess(context, 'Downloading ${_selectedIds.length} items...');
                  _clearSelection();
                },
                onRename: () {},
                onMove: () {},
                onTrash: () {
                  final count = _selectedIds.length;
                  _clearSelection();
                  UndoToast.show(
                    context: context,
                    message: 'Moved $count items to trash',
                    onUndo: () => AppToast.showSuccess(context, 'Restored $count items'),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}
