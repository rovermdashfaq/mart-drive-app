import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../../models/file_item.dart';
import '../../services/drive_service.dart';
import '../../utils/drive_helper.dart';
import '../../utils/formatters.dart';

class FileCard extends StatelessWidget {
  final FileItem file;
  final bool isSelected;
  final bool isSelectionMode;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final VoidCallback onStarToggle;
  final VoidCallback onMenuTap;

  const FileCard({
    super.key,
    required this.file,
    this.isSelected = false,
    this.isSelectionMode = false,
    required this.onTap,
    required this.onLongPress,
    required this.onStarToggle,
    required this.onMenuTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isImage = file.mimeType.startsWith('image/');
    final thumbUrl = file.thumb ?? (file.driveFileId.isNotEmpty ? DriveService.getThumbnailUrl(file.driveFileId, 400) : null);

    return Card(
      elevation: isSelected ? 2 : 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
          color: isSelected ? theme.colorScheme.primary : theme.colorScheme.outlineVariant.withValues(alpha: 0.7),
          width: isSelected ? 2.0 : 1.0,
        ),
      ),
      color: isSelected ? theme.colorScheme.primaryContainer.withValues(alpha: 0.25) : theme.cardColor,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        onLongPress: onLongPress,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Top Preview / Thumbnail Area
            Expanded(
              flex: 5,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(13)),
                    child: (thumbUrl != null && (isImage || file.thumb != null))
                        ? CachedNetworkImage(
                            imageUrl: thumbUrl,
                            fit: BoxFit.cover,
                            placeholder: (_, __) => Container(
                              color: theme.colorScheme.surfaceContainerHighest,
                              child: Icon(DriveHelper.getIconForMime(file.mimeType), size: 36, color: theme.colorScheme.primary),
                            ),
                            errorWidget: (_, __, ___) => Container(
                              color: theme.colorScheme.surfaceContainerHighest,
                              child: Icon(DriveHelper.getIconForMime(file.mimeType), size: 36, color: theme.colorScheme.primary),
                            ),
                          )
                        : Container(
                            color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                            child: Icon(
                              DriveHelper.getIconForMime(file.mimeType),
                              size: 40,
                              color: theme.colorScheme.primary,
                            ),
                          ),
                  ),

                  // Selection checkbox
                  if (isSelectionMode)
                    Positioned(
                      top: 6,
                      left: 6,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.4),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          isSelected ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                          color: isSelected ? theme.colorScheme.primary : Colors.white,
                          size: 20,
                        ),
                      ),
                    ),

                  // Star toggle
                  Positioned(
                    top: 4,
                    right: 4,
                    child: IconButton(
                      icon: Icon(
                        file.starred ? Icons.star_rounded : Icons.star_border_rounded,
                        color: file.starred ? const Color(0xFFF59E0B) : Colors.white.withValues(alpha: 0.8),
                        size: 20,
                      ),
                      onPressed: onStarToggle,
                      constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                      padding: EdgeInsets.zero,
                    ),
                  ),
                ],
              ),
            ),

            // Bottom metadata
            Expanded(
              flex: 4,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            file.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.more_vert_rounded, size: 16),
                          constraints: const BoxConstraints(minWidth: 24, minHeight: 24),
                          padding: EdgeInsets.zero,
                          onPressed: onMenuTap,
                        ),
                      ],
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        Text(
                          AppFormatters.fmtSize(file.size),
                          style: TextStyle(
                            fontSize: 11,
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                          ),
                        ),
                        const Spacer(),
                        if (file.orgId != null)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.primary.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              'Org',
                              style: TextStyle(
                                fontSize: 9,
                                fontWeight: FontWeight.bold,
                                color: theme.colorScheme.primary,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
