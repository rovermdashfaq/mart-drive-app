import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:share_plus/share_plus.dart';
import '../../models/file_item.dart';
import '../../services/drive_service.dart';
import '../../widgets/toast.dart';
import 'preview_actions.dart';

class ImagePreviewScreen extends StatelessWidget {
  final FileItem file;

  const ImagePreviewScreen({super.key, required this.file});

  @override
  Widget build(BuildContext context) {
    final thumbUrl = file.thumb ?? DriveService.getThumbnailUrl(file.driveFileId, 1600);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(file.name, style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_rounded),
            onPressed: () => Share.shareUri(Uri.parse(thumbUrl)),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: PhotoView(
              imageProvider: CachedNetworkImageProvider(thumbUrl),
              minScale: PhotoViewComputedScale.contained,
              maxScale: PhotoViewComputedScale.covered * 2.5,
              heroAttributes: PhotoViewHeroAttributes(tag: file.id),
              loadingBuilder: (_, __) => const Center(
                child: CircularProgressIndicator(color: Colors.white),
              ),
              errorBuilder: (_, __, ___) => const Center(
                child: Text('Unable to load full image preview', style: TextStyle(color: Colors.white70)),
              ),
            ),
          ),
          PreviewBottomActionBar(
            onDownload: () => AppToast.showSuccess(context, 'Downloading image to Gallery...'),
            onShare: () => Share.shareUri(Uri.parse(thumbUrl)),
            onComments: () => AppToast.showSuccess(context, 'Comments drawer'),
            onInfo: () {},
          ),
        ],
      ),
    );
  }
}
