import 'package:flutter/material.dart';

class PreviewBottomActionBar extends StatelessWidget {
  final VoidCallback onDownload;
  final VoidCallback onShare;
  final VoidCallback onComments;
  final VoidCallback onInfo;
  final VoidCallback? onRename;

  const PreviewBottomActionBar({
    super.key,
    required this.onDownload,
    required this.onShare,
    required this.onComments,
    required this.onInfo,
    this.onRename,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(top: BorderSide(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5))),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(
              icon: const Icon(Icons.download_rounded),
              tooltip: 'Download',
              onPressed: onDownload,
            ),
            IconButton(
              icon: const Icon(Icons.share_rounded),
              tooltip: 'Share Link',
              onPressed: onShare,
            ),
            IconButton(
              icon: const Icon(Icons.comment_outlined),
              tooltip: 'Comments',
              onPressed: onComments,
            ),
            if (onRename != null)
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                tooltip: 'Rename',
                onPressed: onRename,
              ),
            IconButton(
              icon: const Icon(Icons.info_outline_rounded),
              tooltip: 'Details & Activity',
              onPressed: onInfo,
            ),
          ],
        ),
      ),
    );
  }
}
