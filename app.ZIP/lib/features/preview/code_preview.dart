import 'package:flutter/material.dart';
import 'package:flutter_highlight/flutter_highlight.dart';
import 'package:flutter_highlight/themes/atom-one-dark.dart';
import '../../core/constants.dart';
import '../../models/file_item.dart';
import 'preview_actions.dart';

class CodePreviewScreen extends StatelessWidget {
  final FileItem file;
  final String sourceCode;

  const CodePreviewScreen({
    super.key,
    required this.file,
    required this.sourceCode,
  });

  String _detectLanguage() {
    final ext = file.name.split('.').last.toLowerCase();
    return AppConstants.langMap[ext] ?? 'plaintext';
  }

  @override
  Widget build(BuildContext context) {
    final language = _detectLanguage();
    final lines = sourceCode.split('\n');

    return Scaffold(
      backgroundColor: const Color(0xFF282C34),
      appBar: AppBar(
        backgroundColor: const Color(0xFF21252B),
        foregroundColor: Colors.white,
        title: Text(file.name, style: const TextStyle(fontSize: 15)),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              scrollDirection: Axis.vertical,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Line numbers column
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: List.generate(
                        lines.length,
                        (index) => Text(
                          '${index + 1}  ',
                          style: const TextStyle(
                            fontFamily: 'monospace',
                            color: Color(0xFF5C6370),
                            fontSize: 13,
                            height: 1.45,
                          ),
                        ),
                      ),
                    ),
                    // Highlighted Code Block
                    HighlightView(
                      sourceCode,
                      language: language,
                      theme: atomOneDarkTheme,
                      textStyle: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 13,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          PreviewBottomActionBar(
            onDownload: () {},
            onShare: () {},
            onComments: () {},
            onInfo: () {},
          ),
        ],
      ),
    );
  }
}
