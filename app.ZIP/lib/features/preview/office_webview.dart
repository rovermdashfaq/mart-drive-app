import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import '../../models/file_item.dart';
import 'preview_actions.dart';

class OfficeWebViewScreen extends StatefulWidget {
  final FileItem file;

  const OfficeWebViewScreen({super.key, required this.file});

  @override
  State<OfficeWebViewScreen> createState() => _OfficeWebViewScreenState();
}

class _OfficeWebViewScreenState extends State<OfficeWebViewScreen> {
  bool _isLoading = true;

  @override
  Widget build(BuildContext context) {
    // Official Google Drive embedded document preview URL
    final drivePreviewUrl = 'https://drive.google.com/file/d/${widget.file.driveFileId}/preview';

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.file.name, style: const TextStyle(fontSize: 16)),
      ),
      body: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                InAppWebView(
                  initialUrlRequest: URLRequest(url: WebUri(drivePreviewUrl)),
                  onLoadStop: (controller, url) {
                    setState(() => _isLoading = false);
                  },
                ),
                if (_isLoading)
                  const Center(
                    child: CircularProgressIndicator(),
                  ),
              ],
            ),
          ),
          PreviewBottomActionBar(
            onDownload: () {},
            onShare: () {},
            onComments: () {},
            onInfo: () {},
          ),
        ],
      ),
    );
  }
}
