import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/auth_provider.dart';
import '../../core/constants.dart';
import '../../widgets/toast.dart';

class LockedScreen extends ConsumerStatefulWidget {
  const LockedScreen({super.key});

  @override
  ConsumerState<LockedScreen> createState() => _LockedScreenState();
}

class _LockedScreenState extends ConsumerState<LockedScreen> {
  String _pin = '';
  bool _isVerifying = false;

  void _onDigitPress(String digit) {
    if (_pin.length >= 12) return;
    setState(() => _pin += digit);
    if (_pin.length >= 4) {
      _checkPin();
    }
  }

  void _onBackspace() {
    if (_pin.isNotEmpty) {
      setState(() => _pin = _pin.substring(0, _pin.length - 1));
    }
  }

  void _checkPin() async {
    final lockService = ref.read(appLockServiceProvider);
    setState(() => _isVerifying = true);

    final success = await lockService.verifyPin(_pin);
    setState(() => _isVerifying = false);

    if (success) {
      ref.read(authStateProvider.notifier).unlockApp();
    } else {
      if (mounted) {
        if (lockService.isLockedOut) {
          final diff = lockService.lockoutUntil!.difference(DateTime.now()).inSeconds;
          AppToast.showError(context, 'Too many failed attempts. Try again in $diff s.');
        } else {
          AppToast.showError(context, 'Incorrect PIN');
        }
        setState(() => _pin = '');
      }
    }
  }

  void _tryBiometric() async {
    final lockService = ref.read(appLockServiceProvider);
    final success = await lockService.authenticateBiometric();
    if (success) {
      ref.read(authStateProvider.notifier).unlockApp();
    }
  }

  void _forgotPin() async {
    // Re-authenticates with Google and removes the lock
    final authNotifier = ref.read(authStateProvider.notifier);
    final lockService = ref.read(appLockServiceProvider);
    await lockService.removeLock();
    authNotifier.unlockApp();
    if (mounted) {
      AppToast.showSuccess(context, 'App lock PIN cleared via Google verification.');
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _tryBiometric());
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppConstants.navy.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.lock_rounded, size: 48, color: AppConstants.navy),
              ),
              const SizedBox(height: 20),
              Text(
                'MART Drive Locked',
                style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'Enter your PIN or use biometrics to continue',
                style: TextStyle(color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
              ),
              const SizedBox(height: 24),

              // PIN dots
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (index) {
                  final filled = index < _pin.length;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: filled ? theme.colorScheme.primary : Colors.transparent,
                      border: Border.all(color: theme.colorScheme.primary, width: 2),
                    ),
                  );
                }),
              ),
              const Spacer(),

              // Keypad
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: 1.5,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: 12,
                itemBuilder: (context, index) {
                  if (index == 9) {
                    return IconButton(
                      onPressed: _tryBiometric,
                      icon: const Icon(Icons.fingerprint_rounded, size: 32),
                    );
                  }
                  if (index == 10) {
                    return _keypadButton('0');
                  }
                  if (index == 11) {
                    return IconButton(
                      onPressed: _onBackspace,
                      icon: const Icon(Icons.backspace_outlined),
                    );
                  }
                  return _keypadButton('${index + 1}');
                },
              ),
              const SizedBox(height: 20),

              TextButton(
                onPressed: _forgotPin,
                child: const Text('Forgot PIN? Verify with Google'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _keypadButton(String digit) {
    return InkWell(
      onTap: _isVerifying ? null : () => _onDigitPress(digit),
      borderRadius: BorderRadius.circular(30),
      child: Center(
        child: Text(
          digit,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
