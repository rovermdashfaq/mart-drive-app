import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/auth_provider.dart';
import '../../core/constants.dart';
import '../../widgets/toast.dart';

class WelcomeScreen extends ConsumerStatefulWidget {
  const WelcomeScreen({super.key});

  @override
  ConsumerState<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends ConsumerState<WelcomeScreen> {
  final TextEditingController _appealController = TextEditingController();
  bool _isSubmittingAppeal = false;

  void _openUrl(String path) {
    launchUrl(
      Uri.parse('${AppConstants.webAppUrl}/$path'),
      mode: LaunchMode.inAppWebView,
    );
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authStateProvider);
    final theme = Theme.of(context);

    // If blocked, render appeal screen
    if (authState.blockedReason != null) {
      return Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Icon(Icons.block_rounded, size: 64, color: Color(0xFFEF4444)),
                const SizedBox(height: 16),
                const Text(
                  'Account Suspended',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  authState.blockedReason!,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: theme.colorScheme.onSurface.withValues(alpha: 0.7)),
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: _appealController,
                  maxLines: 4,
                  decoration: InputDecoration(
                    hintText: 'Explain why your account should be reinstated...',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: _isSubmittingAppeal
                      ? null
                      : () async {
                          if (_appealController.text.trim().isEmpty) return;
                          setState(() => _isSubmittingAppeal = true);
                          // Submit appeal
                          AppToast.showSuccess(context, 'Appeal submitted to MART administrators.');
                          setState(() => _isSubmittingAppeal = false);
                        },
                  child: _isSubmittingAppeal
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('Submit Appeal'),
                ),
                TextButton(
                  onPressed: () {
                    ref.read(authStateProvider.notifier).signOut();
                  },
                  child: const Text('Back to Login'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28.0, vertical: 24.0),
          child: Column(
            children: [
              const Spacer(),
              // Logo
              ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: Image.network(
                  AppConstants.logoUrl,
                  width: 100,
                  height: 100,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: AppConstants.navy,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: const Icon(Icons.cloud_queue_rounded, size: 52, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                AppConstants.appName,
                style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                  color: theme.colorScheme.primary,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                AppConstants.appTagline,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                  height: 1.4,
                ),
              ),
              const Spacer(),

              // Sign in buttons
              if (authState.isLoading)
                const CircularProgressIndicator()
              else ...[
                OutlinedButton.icon(
                  onPressed: () => ref.read(authStateProvider.notifier).signInWithGoogle(),
                  icon: Image.network(
                    'https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg',
                    width: 20,
                    height: 20,
                    errorBuilder: (_, __, ___) => const Icon(Icons.g_mobiledata_rounded, size: 24),
                  ),
                  label: const Text(
                    'Continue with Google',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size.fromHeight(52),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: () => ref.read(authStateProvider.notifier).signInWithGoogle(),
                  icon: const Icon(Icons.person_add_outlined, size: 20),
                  label: const Text(
                    'Sign up with Google',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                  style: FilledButton.styleFrom(
                    minimumSize: const Size.fromHeight(52),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ],

              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    onPressed: () => _openUrl('privacy.html'),
                    child: const Text('Privacy Policy', style: TextStyle(fontSize: 12)),
                  ),
                  const Text('·', style: TextStyle(color: Colors.grey)),
                  TextButton(
                    onPressed: () => _openUrl('terms.html'),
                    child: const Text('Terms of Service', style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
