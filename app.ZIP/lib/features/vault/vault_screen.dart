import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/auth_provider.dart';
import '../../services/vault_service.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/toast.dart';

final vaultServiceProvider = Provider<VaultService>((ref) => VaultService());

class VaultScreen extends ConsumerStatefulWidget {
  const VaultScreen({super.key});

  @override
  ConsumerState<VaultScreen> createState() => _VaultScreenState();
}

class _VaultScreenState extends ConsumerState<VaultScreen> {
  String _enteredPin = '';
  bool _isCreatingPin = false;
  String _firstEnteredPin = '';
  bool _hasPinConfigured = true;
  bool _isCheckingStatus = true;

  @override
  void initState() {
    super.initState();
    _checkVaultStatus();
  }

  void _checkVaultStatus() async {
    final vaultService = ref.read(vaultServiceProvider);
    final user = ref.read(authStateProvider).user;
    if (user != null) {
      final exists = await vaultService.hasVaultPin(user.uid);
      if (mounted) {
        setState(() {
          _hasPinConfigured = exists;
          _isCreatingPin = !exists;
          _isCheckingStatus = false;
        });
      }
    } else {
      setState(() => _isCheckingStatus = false);
    }
  }

  void _onDigitPress(String digit) {
    if (_enteredPin.length >= 6) return;
    setState(() => _enteredPin += digit);

    if (_enteredPin.length == 4) {
      _processPin();
    }
  }

  void _processPin() async {
    final vaultService = ref.read(vaultServiceProvider);
    final user = ref.read(authStateProvider).user;
    if (user == null) return;

    if (_isCreatingPin) {
      if (_firstEnteredPin.isEmpty) {
        setState(() {
          _firstEnteredPin = _enteredPin;
          _enteredPin = '';
        });
        AppToast.showSuccess(context, 'Confirm your new Vault PIN');
      } else {
        if (_enteredPin == _firstEnteredPin) {
          await vaultService.setupVaultPin(user.uid, _enteredPin);
          setState(() {
            _hasPinConfigured = true;
            _isCreatingPin = false;
          });
          if (mounted) AppToast.showSuccess(context, 'Vault PIN established');
        } else {
          AppToast.showError(context, 'PINs did not match. Try again.');
          setState(() {
            _firstEnteredPin = '';
            _enteredPin = '';
          });
        }
      }
    } else {
      final ok = await vaultService.verifyVaultPin(user.uid, _enteredPin);
      if (ok) {
        setState(() => _enteredPin = '');
      } else {
        if (mounted) {
          AppToast.showError(context, 'Incorrect Vault PIN');
          setState(() => _enteredPin = '');
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final vaultService = ref.watch(vaultServiceProvider);
    final theme = Theme.of(context);

    if (_isCheckingStatus) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    // If unlocked, render vault content
    if (vaultService.isUnlocked) {
      return Scaffold(
        appBar: AppBar(
          title: const Row(
            children: [
              Icon(Icons.shield_rounded, color: Color(0xFF10B981)),
              SizedBox(width: 8),
              Text('Secure Vault', style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.lock_outline_rounded),
              tooltip: 'Lock Vault',
              onPressed: () {
                vaultService.lock();
                setState(() {});
              },
            ),
          ],
        ),
        body: EmptyStateWidget.forView('vault'),
      );
    }

    // PIN entry gate
    return Scaffold(
      appBar: AppBar(title: const Text('Vault Access')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFF163A5F).withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.shield_outlined, size: 48, color: Color(0xFF163A5F)),
              ),
              const SizedBox(height: 20),
              Text(
                _isCreatingPin
                    ? (_firstEnteredPin.isEmpty ? 'Set a Vault PIN' : 'Confirm Vault PIN')
                    : 'Enter Vault PIN',
                style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'This PIN encrypts private files and notes',
                style: TextStyle(color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
              ),
              const SizedBox(height: 24),

              // PIN indicators
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (index) {
                  final filled = index < _enteredPin.length;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: filled ? theme.colorScheme.primary : Colors.transparent,
                      border: Border.all(color: theme.colorScheme.primary, width: 2),
                    ),
                  );
                }),
              ),
              const Spacer(),

              // Keypad
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: 1.5,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: 12,
                itemBuilder: (context, index) {
                  if (index == 9) return const SizedBox.shrink();
                  if (index == 10) return _keypadButton('0');
                  if (index == 11) {
                    return IconButton(
                      onPressed: () {
                        if (_enteredPin.isNotEmpty) {
                          setState(() => _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1));
                        }
                      },
                      icon: const Icon(Icons.backspace_outlined),
                    );
                  }
                  return _keypadButton('${index + 1}');
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _keypadButton(String digit) {
    return InkWell(
      onTap: () => _onDigitPress(digit),
      borderRadius: BorderRadius.circular(30),
      child: Center(
        child: Text(
          digit,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
