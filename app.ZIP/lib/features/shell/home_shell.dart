import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/auth_provider.dart';
import '../../core/constants.dart';
import '../../widgets/toast.dart';
import 'create_sheet.dart';

class HomeShell extends ConsumerStatefulWidget {
  final Widget child;

  const HomeShell({super.key, required this.child});

  @override
  ConsumerState<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends ConsumerState<HomeShell> {
  int _calculateSelectedIndex(BuildContext context) {
    final location = GoRouterState.of(context).uri.toString();
    if (location.startsWith('/drive')) return 1;
    if (location.startsWith('/shared')) return 3;
    if (location.startsWith('/profile')) return 4;
    return 0; // Home
  }

  void _onItemTapped(int index, BuildContext context) {
    switch (index) {
      case 0:
        context.go('/home');
        break;
      case 1:
        context.go('/drive');
        break;
      case 2:
        _openCreateSheet(context);
        break;
      case 3:
        context.go('/shared');
        break;
      case 4:
        context.go('/profile');
        break;
    }
  }

  void _openCreateSheet(BuildContext context) async {
    final action = await CreateBottomSheet.show(context);
    if (action == null || !context.mounted) return;

    switch (action) {
      case CreateAction.uploadFile:
        context.push('/upload');
        break;
      case CreateAction.uploadFolder:
        AppToast.showSuccess(context, 'Select a directory to upload');
        context.push('/upload?folder=true');
        break;
      case CreateAction.newFolder:
        _showNewFolderDialog(context);
        break;
      case CreateAction.newNote:
        context.push('/notes/new');
        break;
      case CreateAction.newLink:
        context.push('/links/new');
        break;
      case CreateAction.scanQr:
        context.push('/scan');
        break;
      case CreateAction.createOrg:
        context.push('/org/create');
        break;
    }
  }

  void _showNewFolderDialog(BuildContext context) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New Folder'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Folder name'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              final name = controller.text.trim();
              if (name.isNotEmpty) {
                Navigator.pop(ctx);
                AppToast.showSuccess(context, 'Folder "$name" created');
              }
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final selectedIndex = _calculateSelectedIndex(context);

    return Scaffold(
      body: widget.child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (idx) => _onItemTapped(idx, context),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.folder_outlined),
            selectedIcon: Icon(Icons.folder_rounded),
            label: 'Drive',
          ),
          NavigationDestination(
            icon: Icon(Icons.add_circle_outline_rounded),
            selectedIcon: Icon(Icons.add_circle_rounded),
            label: 'Create',
          ),
          NavigationDestination(
            icon: Icon(Icons.people_outline_rounded),
            selectedIcon: Icon(Icons.people_rounded),
            label: 'Shared',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
