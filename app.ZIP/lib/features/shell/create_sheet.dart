import 'package:flutter/material.dart';

enum CreateAction {
  uploadFile,
  uploadFolder,
  newNote,
  newLink,
  newFolder,
  scanQr,
  createOrg,
}

class CreateBottomSheet extends StatelessWidget {
  final Function(CreateAction action) onSelect;

  const CreateBottomSheet({super.key, required this.onSelect});

  static Future<CreateAction?> show(BuildContext context) {
    return showModalBottomSheet<CreateAction>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => CreateBottomSheet(
        onSelect: (action) => Navigator.pop(ctx, action),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final items = [
      {'action': CreateAction.uploadFile, 'icon': Icons.upload_file_rounded, 'title': 'Upload File', 'sub': 'Photos, videos, PDFs & docs'},
      {'action': CreateAction.uploadFolder, 'icon': Icons.drive_folder_upload_rounded, 'title': 'Upload Folder', 'sub': 'Upload entire folder recursively'},
      {'action': CreateAction.newFolder, 'icon': Icons.create_new_folder_outlined, 'title': 'New Folder', 'sub': 'Create nested directory'},
      {'action': CreateAction.newNote, 'icon': Icons.edit_note_rounded, 'title': 'New Note', 'sub': 'Collaborative rich markdown note'},
      {'action': CreateAction.newLink, 'icon': Icons.link_rounded, 'title': 'New Link', 'sub': 'Rich bookmark with preview card'},
      {'action': CreateAction.scanQr, 'icon': Icons.qr_code_scanner_rounded, 'title': 'Scan QR', 'sub': 'Join organization or open file'},
      {'action': CreateAction.createOrg, 'icon': Icons.business_rounded, 'title': 'Create Organization', 'sub': 'Set up a shared team workspace'},
    ];

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Text(
                'Create or Upload',
                style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 12),
            ...items.map((it) {
              final action = it['action'] as CreateAction;
              final icon = it['icon'] as IconData;
              final title = it['title'] as String;
              final sub = it['sub'] as String;

              return ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: theme.colorScheme.primary, size: 22),
                ),
                title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                subtitle: Text(sub, style: TextStyle(fontSize: 12, color: theme.colorScheme.onSurface.withValues(alpha: 0.6))),
                onTap: () => onSelect(action),
              );
            }),
          ],
        ),
      ),
    );
  }
}
