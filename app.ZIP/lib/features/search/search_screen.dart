import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../models/file_item.dart';
import '../../utils/drive_helper.dart';
import '../../utils/formatters.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  Timer? _debounceTimer;
  String _selectedType = 'All';
  List<FileItem> _results = [];
  bool _isSearching = false;

  void _onQueryChanged(String query) {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 300), () {
      _executeSearch(query.trim());
    });
  }

  void _executeSearch(String query) {
    if (query.isEmpty) {
      setState(() {
        _results = [];
        _isSearching = false;
      });
      return;
    }

    setState(() => _isSearching = true);

    // Mock search matching query across personal and org collections
    final mockResults = [
      FileItem(
        id: 'f_search_1',
        driveFileId: 'drive_s1',
        name: '$query Specs & Design.pdf',
        mimeType: 'application/pdf',
        size: 1980000,
        uid: 'uid_1',
        orgId: 'org_mart_core',
        createdAt: DateTime.now().subtract(const Duration(days: 3)),
      ),
      FileItem(
        id: 'f_search_2',
        driveFileId: 'drive_s2',
        name: 'Report_$query.xlsx',
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        size: 890000,
        uid: 'uid_1',
        createdAt: DateTime.now().subtract(const Duration(days: 7)),
      ),
    ];

    setState(() {
      _results = mockResults;
      _isSearching = false;
    });
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: TextField(
          controller: _searchController,
          autofocus: true,
          onChanged: _onQueryChanged,
          decoration: const InputDecoration(
            hintText: 'Search files, notes & folders...',
            border: InputBorder.none,
          ),
        ),
        actions: [
          if (_searchController.text.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear_rounded),
              onPressed: () {
                _searchController.clear();
                _executeSearch('');
              },
            ),
        ],
      ),
      body: Column(
        children: [
          // Filter chips
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: ['All', 'PDFs', 'Spreadsheets', 'Images', 'Notes', 'Starred'].map((type) {
                final isSelected = _selectedType == type;
                return Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: FilterChip(
                    label: Text(type),
                    selected: isSelected,
                    onSelected: (_) => setState(() => _selectedType = type),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  ),
                );
              }).toList(),
            ),
          ),
          const Divider(height: 1),

          // Search Results
          Expanded(
            child: _isSearching
                ? const Center(child: CircularProgressIndicator())
                : _results.isEmpty
                    ? Center(
                        child: Text(
                          _searchController.text.isEmpty
                              ? 'Type a keyword to search across personal and team drives'
                              : 'No matching files found',
                          style: TextStyle(color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _results.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (context, index) {
                          final item = _results[index];
                          return Card(
                            child: ListTile(
                              leading: Icon(DriveHelper.getIconForMime(item.mimeType), color: theme.colorScheme.primary),
                              title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                              subtitle: Row(
                                children: [
                                  Text('${AppFormatters.fmtSize(item.size)} · ${AppFormatters.ago(item.createdAt)}'),
                                  if (item.orgId != null) ...[
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: Colors.blue.withValues(alpha: 0.1),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: const Text('MART Engineering', style: TextStyle(fontSize: 9, color: Colors.blue)),
                                    ),
                                  ],
                                ],
                              ),
                              onTap: () => context.push('/preview/${item.id}'),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
