import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../../models/note_item.dart';
import '../../services/preview_service.dart';
import '../../widgets/toast.dart';

class LinkEditorScreen extends StatefulWidget {
  final String? initialUrl;

  const LinkEditorScreen({super.key, this.initialUrl});

  @override
  State<LinkEditorScreen> createState() => _LinkEditorScreenState();
}

class _LinkEditorScreenState extends State<LinkEditorScreen> {
  final TextEditingController _urlController = TextEditingController();
  final TextEditingController _titleController = TextEditingController();
  LinkPreviewData? _preview;
  bool _isLoadingPreview = false;
  Timer? _debounceTimer;

  @override
  void initState() {
    super.initState();
    if (widget.initialUrl != null) {
      _urlController.text = widget.initialUrl!;
      _fetchPreview(widget.initialUrl!);
    }
  }

  void _onUrlChanged(String text) {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 700), () {
      if (text.trim().length > 4) {
        _fetchPreview(text.trim());
      }
    });
  }

  void _fetchPreview(String url) async {
    setState(() => _isLoadingPreview = true);
    final data = await PreviewService.fetchLinkPreview(url);
    if (mounted) {
      setState(() {
        _preview = data;
        _isLoadingPreview = false;
        if (_titleController.text.isEmpty && data?.title != null) {
          _titleController.text = data!.title!;
        }
      });
    }
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    _urlController.dispose();
    _titleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Link Bookmark', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          FilledButton(
            onPressed: () {
              if (_urlController.text.trim().isEmpty) return;
              AppToast.showSuccess(context, 'Link saved with rich preview');
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: _urlController,
            onChanged: _onUrlChanged,
            decoration: InputDecoration(
              labelText: 'Web Address (URL)',
              hintText: 'https://example.com/article',
              prefixIcon: const Icon(Icons.link_rounded),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _titleController,
            decoration: InputDecoration(
              labelText: 'Title (optional)',
              hintText: 'Custom title for this link',
              prefixIcon: const Icon(Icons.title_rounded),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          const SizedBox(height: 24),
          const Text('Live Link Preview', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 12),

          if (_isLoadingPreview)
            Container(
              height: 140,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 10),
                  Text('Fetching metadata from web...', style: TextStyle(color: Colors.grey)),
                ],
              ),
            )
          else if (_preview != null)
            Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(color: theme.colorScheme.outlineVariant),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (_preview!.image != null)
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
                      child: CachedNetworkImage(
                        imageUrl: _preview!.image!,
                        height: 150,
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => const SizedBox.shrink(),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.all(14.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (_preview!.site != null)
                          Text(
                            _preview!.site!.toUpperCase(),
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: theme.colorScheme.primary,
                            ),
                          ),
                        const SizedBox(height: 4),
                        Text(
                          _preview!.title ?? 'No title',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                        if (_preview!.description != null) ...[
                          const SizedBox(height: 4),
                          Text(
                            _preview!.description!,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 12, color: theme.colorScheme.onSurface.withValues(alpha: 0.7)),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            )
          else
            Container(
              height: 100,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300, style: BorderStyle.solid),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Text('Enter a link above to generate live card preview', style: TextStyle(color: Colors.grey)),
            ),
        ],
      ),
    );
  }
}
