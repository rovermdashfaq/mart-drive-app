import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../models/note_item.dart';
import '../../services/merge_service.dart';
import '../../widgets/toast.dart';

class LiveNoteEditorScreen extends StatefulWidget {
  final String noteId;
  final NoteItem? initialNote;

  const LiveNoteEditorScreen({
    super.key,
    required this.noteId,
    this.initialNote,
  });

  @override
  State<LiveNoteEditorScreen> createState() => _LiveNoteEditorScreenState();
}

class _LiveNoteEditorScreenState extends State<LiveNoteEditorScreen> {
  late TextEditingController _titleController;
  late TextEditingController _contentController;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String _baseContent = '';
  String _baseTitle = '';
  String _currentColor = '';
  String? _lostConflictText;

  Timer? _debounceTimer;
  StreamSubscription<DocumentSnapshot>? _noteSub;
  bool _isComposing = false;

  @override
  void initState() {
    super.initState();
    _baseTitle = widget.initialNote?.name ?? 'Untitled Note';
    _baseContent = widget.initialNote?.content ?? '';
    _currentColor = widget.initialNote?.color ?? '';

    _titleController = TextEditingController(text: _baseTitle);
    _contentController = TextEditingController(text: _baseContent);

    _listenToRemoteEdits();
  }

  void _listenToRemoteEdits() {
    _noteSub = _firestore.collection('notes').doc(widget.noteId).snapshots().listen((snap) {
      if (!snap.exists) return;
      final data = snap.data();
      if (data == null) return;

      final serverContent = data['content'] as String? ?? '';
      final serverTitle = data['name'] as String? ?? 'Untitled Note';

      // Never overwrite while local user is actively typing
      if (_isComposing) return;

      if (serverContent != _contentController.text && serverContent != _baseContent) {
        // Perform 3-way merge
        final merge = MergeService.m3(_baseContent, _contentController.text, serverContent);

        if (merge.hasConflict) {
          _lostConflictText = merge.conflictText;
          _contentController.text = merge.text;
          _baseContent = merge.text;

          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: const Text('Someone edited the same text. Server version was kept.'),
                action: SnackBarAction(
                  label: 'Restore mine',
                  onPressed: () {
                    if (_lostConflictText != null) {
                      setState(() {
                        _contentController.text = _lostConflictText!;
                        _scheduleCommit();
                      });
                    }
                  },
                ),
              ),
            );
          }
        } else {
          _contentController.text = merge.text;
          _baseContent = merge.text;
        }
      }

      if (serverTitle != _titleController.text && serverTitle != _baseTitle) {
        _titleController.text = serverTitle;
        _baseTitle = serverTitle;
      }
    });
  }

  void _onContentChanged(String val) {
    _isComposing = true;
    _scheduleCommit();
  }

  void _scheduleCommit() {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 700), () {
      _isComposing = false;
      _commitTransaction();
    });
  }

  Future<void> _commitTransaction() async {
    final mineContent = _contentController.text;
    final mineTitle = _titleController.text;

    try {
      final docRef = _firestore.collection('notes').doc(widget.noteId);

      await _firestore.runTransaction((transaction) async {
        final snapshot = await transaction.get(docRef);
        if (!snapshot.exists) {
          transaction.set(docRef, {
            'name': mineTitle,
            'content': mineContent,
            'color': _currentColor,
            'ntype': 'note',
            'updatedAt': FieldValue.serverTimestamp(),
          });
          _baseContent = mineContent;
          _baseTitle = mineTitle;
          return;
        }

        final serverData = snapshot.data()!;
        final serverContent = serverData['content'] as String? ?? '';
        final serverTitle = serverData['name'] as String? ?? '';
        final serverColor = serverData['color'] as String? ?? '';

        final merge = MergeService.m3(_baseContent, mineContent, serverContent);
        final finalContent = merge.text;
        final finalTitle = (mineTitle != _baseTitle) ? mineTitle : serverTitle;
        final finalColor = (_currentColor.isNotEmpty) ? _currentColor : serverColor;

        transaction.update(docRef, {
          'name': finalTitle,
          'content': finalContent,
          'color': finalColor,
          'updatedAt': FieldValue.serverTimestamp(),
        });

        _baseContent = finalContent;
        _baseTitle = finalTitle;
      });
    } catch (_) {}
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    _noteSub?.cancel();
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _titleController,
          onChanged: (val) => _scheduleCommit(),
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          decoration: const InputDecoration(
            hintText: 'Note Title',
            border: InputBorder.none,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.palette_outlined),
            onPressed: _showColorPicker,
          ),
          IconButton(
            icon: const Icon(Icons.cloud_done_outlined),
            tooltip: 'Saved',
            onPressed: () => AppToast.showSuccess(context, 'Note synced with live cloud'),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
        child: TextField(
          controller: _contentController,
          onChanged: _onContentChanged,
          maxLines: null,
          expands: true,
          style: const TextStyle(fontSize: 16, height: 1.5),
          decoration: const InputDecoration(
            hintText: 'Start writing markdown note...',
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }

  void _showColorPicker() {
    final colors = [
      {'code': '', 'color': Colors.transparent, 'label': 'Default'},
      {'code': '#F59E0B', 'color': const Color(0xFFF59E0B), 'label': 'Amber'},
      {'code': '#10B981', 'color': const Color(0xFF10B981), 'label': 'Emerald'},
      {'code': '#3B82F6', 'color': const Color(0xFF3B82F6), 'label': 'Blue'},
      {'code': '#EC4899', 'color': const Color(0xFFEC4899), 'label': 'Pink'},
    ];

    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Note Color', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: colors.map((c) {
                  final code = c['code'] as String;
                  final color = c['color'] as Color;
                  return InkWell(
                    onTap: () {
                      setState(() => _currentColor = code);
                      _scheduleCommit();
                      Navigator.pop(ctx);
                    },
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: color == Colors.transparent ? Colors.grey.shade200 : color,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.grey.shade400, width: 2),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
