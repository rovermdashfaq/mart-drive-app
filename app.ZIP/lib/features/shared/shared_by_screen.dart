import 'package:flutter/material.dart';
import '../../models/share.dart';
import '../../widgets/empty_state.dart';
import '../../utils/drive_helper.dart';

class SharedScreen extends StatefulWidget {
  const SharedScreen({super.key});

  @override
  State<SharedScreen> createState() => _SharedScreenState();
}

class _SharedScreenState extends State<SharedScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final sampleSharedBy = [
      ShareItem(
        id: 's1',
        fileId: 'f_101',
        driveFileId: 'drive_101',
        name: 'Product Roadmap 2026.pdf',
        mimeType: 'application/pdf',
        size: 2100000,
        ownerUid: 'uid_1',
        ownerEmail: 'owner@mart.com',
        email: 'collaborator@external.com',
        role: 'writer',
        createdAt: DateTime.now().subtract(const Duration(days: 2)),
      ),
      ShareItem(
        id: 's2',
        fileId: 'f_102',
        driveFileId: 'drive_102',
        name: 'Brand Guidelines.png',
        mimeType: 'image/png',
        size: 1500000,
        ownerUid: 'uid_1',
        ownerEmail: 'owner@mart.com',
        email: 'client@studio.com',
        role: 'reader',
        createdAt: DateTime.now().subtract(const Duration(days: 5)),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Shared Items', style: TextStyle(fontWeight: FontWeight.bold)),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Shared by me'),
            Tab(text: 'Shared from others'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Sub-tab 1: Shared by me (grouped by fileId)
          sampleSharedBy.isEmpty
              ? EmptyStateWidget.forView('shared')
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: sampleSharedBy.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final item = sampleSharedBy[index];
                    return Card(
                      child: ListTile(
                        leading: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.primary.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(DriveHelper.getIconForMime(item.mimeType), color: theme.colorScheme.primary),
                        ),
                        title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('Shared with ${item.email} (${item.role})'),
                        trailing: PopupMenuButton<String>(
                          itemBuilder: (_) => [
                            const PopupMenuItem(value: 'access', child: Text('Manage access')),
                            const PopupMenuItem(value: 'stopall', child: Text('Stop sharing', style: TextStyle(color: Colors.red))),
                          ],
                        ),
                      ),
                    );
                  },
                ),

          // Sub-tab 2: Shared from others
          EmptyStateWidget.forView('shared'),
        ],
      ),
    );
  }
}
