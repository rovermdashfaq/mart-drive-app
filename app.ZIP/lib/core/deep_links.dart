import 'package:go_router/go_router.dart';

class DeepLinkHandler {
  /// Parses incoming URI scheme or https URL and routes appropriately
  static String? parseDeepLinkToRoute(Uri uri) {
    // Schema: martdrive://join/<code>
    // or https://mart-drive.vercel.app/join/<code>
    final pathSegments = uri.pathSegments;
    final host = uri.host;

    if (host == 'join' || (pathSegments.isNotEmpty && pathSegments[0] == 'join')) {
      final code = host == 'join' ? (pathSegments.isNotEmpty ? pathSegments[0] : '') : pathSegments[1];
      return '/join/$code';
    }

    if (host == 'guest' || (pathSegments.isNotEmpty && pathSegments[0] == 'guest')) {
      final code = host == 'guest' ? (pathSegments.isNotEmpty ? pathSegments[0] : '') : pathSegments[1];
      return '/guest/$code';
    }

    if (host == 'file' || (pathSegments.isNotEmpty && pathSegments[0] == 'file')) {
      final target = host == 'file' ? (pathSegments.isNotEmpty ? pathSegments[0] : '') : pathSegments[1];
      return '/shared/file/$target';
    }

    if (host == 'fshare' || (pathSegments.isNotEmpty && pathSegments[0] == 'fshare')) {
      final target = host == 'fshare' ? (pathSegments.isNotEmpty ? pathSegments[0] : '') : pathSegments[1];
      return '/shared/folder/$target';
    }

    return null;
  }
}
