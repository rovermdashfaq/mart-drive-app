import 'package:flutter/material.dart';

/// MART Drive system-wide constants matching the web app (mart-drive.vercel.app)
class AppConstants {
  static const String appName = 'MART Drive';
  static const String appTagline = 'One secure workspace for your files, notes and team';
  static const String webAppUrl = 'https://mart-drive.vercel.app';
  static const String adminUrl = 'https://mart-drive.vercel.app/admin.html';
  static const String superAdminEmail = 'rovermdashfaq@gmail.com';

  // Branding
  static const String logoUrl = 'https://i.ibb.co/zhhYdVdD/Picsart-26-10-26-09-26-17-563.jpg';

  // Google OAuth & Drive
  static const String driveScope = 'https://www.googleapis.com/auth/drive.file';
  static const Duration tokenTtl = Duration(minutes: 55);

  // ImgBB Upload Key
  static const String imgbbApiKey = 'cab7044412d615b8514735a853183975';
  static const String imgbbUploadUrl = 'https://api.imgbb.com/1/upload';

  // FCM Web Push VAPID Key
  static const String fcmVapidKey = 'BEe31zZorlWc0-H2JCn0-rxpCm0RukM101emid69wyycKMnMlXbhZ8KkKqVDCj2E1DD_7EiVWiJ-eUeEruu9GnY';

  // Security & Crypto
  static const int pbkdf2Iterations = 150000;
  static const int saltBytes = 16;
  static const String appLockKey = 'mart_lock_v1';
  static const Duration vaultAutoLockTimeout = Duration(minutes: 5);
  static const Duration sessionHeartbeatInterval = Duration(minutes: 3);
  static const Duration undoToastDuration = Duration(seconds: 10);
  static const Duration regularToastDuration = Duration(milliseconds: 3500);

  // Deep Link Scheme
  static const String deepLinkScheme = 'martdrive';
  static const String deepLinkHost = 'mart-drive.vercel.app';

  // Primary Theme Colors (from CSS :root blocks)
  static const Color navy = Color(0xFF163A5F);
  static const Color blue = Color(0xFF245B88);
  static const Color lightBg = Color(0xFFF7FAFD);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color darkBg = Color(0xFF0F1A24);
  static const Color darkSurface = Color(0xFF182736);
  static const Color goldAccent = Color(0xFFF59E0B);
  static const Color greenAccent = Color(0xFF10B981);
  static const Color redAccent = Color(0xFFEF4444);

  // Note card pastel background colors
  static const List<String> noteColors = [
    '', // Default
    '#F59E0B', // Amber
    '#10B981', // Emerald
    '#3B82F6', // Blue
    '#EC4899', // Pink
  ];

  // MENUS map exactly matching the web app
  static const Map<String, List<String>> menus = {
    'file': [
      'open', 'star', 'share', 'access', 'download', 'rename',
      'move', 'copy', 'tag', 'up', 'down', 'info', 'trash'
    ],
    'folder': [
      'open', 'star', 'share', 'access', 'rename', 'move',
      'tag', 'icon', 'up', 'down', 'info', 'trash'
    ],
    'note': [
      'open', 'star', 'copytext', 'move', 'copy', 'tag',
      'up', 'down', 'info', 'trash'
    ],
    'sgroup': ['open', 'access', 'stopall'],
    'sfrom': ['open', 'share', 'download', 'info'],
  };

  // Supported Code Highlighting Language Map
  static const Map<String, String> langMap = {
    'js': 'javascript',
    'ts': 'typescript',
    'jsx': 'javascript',
    'tsx': 'typescript',
    'dart': 'dart',
    'py': 'python',
    'java': 'java',
    'kt': 'kotlin',
    'swift': 'swift',
    'c': 'c',
    'cpp': 'cpp',
    'cs': 'csharp',
    'html': 'html',
    'css': 'css',
    'json': 'json',
    'yaml': 'yaml',
    'yml': 'yaml',
    'xml': 'xml',
    'sql': 'sql',
    'sh': 'bash',
    'md': 'markdown',
  };
}
