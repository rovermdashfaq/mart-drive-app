import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../features/auth/welcome_screen.dart';
import '../features/auth/locked_screen.dart';
import '../features/shell/home_shell.dart';
import '../features/files/all_files_screen.dart';
import '../features/files/drive_screen.dart';
import '../features/notes/live_note_editor.dart';
import '../features/notes/link_editor.dart';
import '../features/shared/shared_by_screen.dart';
import '../features/profile/profile_screen.dart';
import '../features/vault/vault_screen.dart';
import '../features/search/search_screen.dart';
import '../models/file_item.dart';
import '../features/preview/image_preview.dart';
import 'auth_provider.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: '/home',
    redirect: (context, state) {
      final isLoggedIn = authState.user != null;
      final isAuthRoute = state.uri.path == '/welcome';

      if (!isLoggedIn) {
        return isAuthRoute ? null : '/welcome';
      }

      if (authState.isAppLocked) {
        return '/locked';
      }

      if (isAuthRoute) {
        return '/home';
      }

      return null;
    },
    routes: [
      GoRoute(
        path: '/welcome',
        builder: (context, state) => const WelcomeScreen(),
      ),
      GoRoute(
        path: '/locked',
        builder: (context, state) => const LockedScreen(),
      ),
      ShellRoute(
        builder: (context, state, child) => HomeShell(child: child),
        routes: [
          GoRoute(
            path: '/home',
            pageBuilder: (context, state) => const CustomTransitionPage(
              child: AllFilesScreen(),
              transitionsBuilder: _sharedAxisTransition,
            ),
          ),
          GoRoute(
            path: '/drive',
            pageBuilder: (context, state) => const CustomTransitionPage(
              child: DriveScreen(),
              transitionsBuilder: _sharedAxisTransition,
            ),
          ),
          GoRoute(
            path: '/shared',
            pageBuilder: (context, state) => const CustomTransitionPage(
              child: SharedScreen(),
              transitionsBuilder: _sharedAxisTransition,
            ),
          ),
          GoRoute(
            path: '/profile',
            pageBuilder: (context, state) => const CustomTransitionPage(
              child: ProfileScreen(),
              transitionsBuilder: _sharedAxisTransition,
            ),
          ),
        ],
      ),
      GoRoute(
        path: '/vault',
        builder: (context, state) => const VaultScreen(),
      ),
      GoRoute(
        path: '/search',
        builder: (context, state) => const SearchScreen(),
      ),
      GoRoute(
        path: '/notes/new',
        builder: (context, state) => const LiveNoteEditorScreen(noteId: 'new_note_id'),
      ),
      GoRoute(
        path: '/links/new',
        builder: (context, state) => const LinkEditorScreen(),
      ),
      GoRoute(
        path: '/preview/:id',
        builder: (context, state) {
          final id = state.pathParameters['id'] ?? 'demo_id';
          return ImagePreviewScreen(
            file: FileItem(
              id: id,
              driveFileId: 'demo_drive_id',
              name: 'MART Drive Document.png',
              mimeType: 'image/png',
              thumb: 'https://i.ibb.co/zhhYdVdD/Picsart-26-10-26-09-26-17-563.jpg',
              size: 2048000,
              uid: 'demo_uid',
            ),
          );
        },
      ),
    ],
  );
});

Widget _sharedAxisTransition(
  BuildContext context,
  Animation<double> animation,
  Animation<double> secondaryAnimation,
  Widget child,
) {
  return FadeTransition(
    opacity: animation,
    child: child,
  );
}
