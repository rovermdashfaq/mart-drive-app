import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/user_profile.dart';
import '../models/organization.dart';
import '../services/auth_service.dart';
import '../services/app_lock_service.dart';
import 'theme.dart';

final authServiceProvider = Provider<AuthService>((ref) => AuthService());
final appLockServiceProvider = Provider<AppLockService>((ref) => AppLockService());

class AuthState {
  final UserProfile? user;
  final bool isLoading;
  final bool isAppLocked;
  final String? blockedReason;

  AuthState({
    this.user,
    this.isLoading = true,
    this.isAppLocked = false,
    this.blockedReason,
  });

  AuthState copyWith({
    UserProfile? user,
    bool? isLoading,
    bool? isAppLocked,
    String? blockedReason,
  }) {
    return AuthState(
      user: user ?? this.user,
      isLoading: isLoading ?? this.isLoading,
      isAppLocked: isAppLocked ?? this.isAppLocked,
      blockedReason: blockedReason ?? this.blockedReason,
    );
  }
}

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthService _authService;
  final AppLockService _lockService;

  AuthNotifier(this._authService, this._lockService) : super(AuthState()) {
    _init();
  }

  void _init() async {
    final currentFirebaseUser = _authService.currentUser;
    if (currentFirebaseUser != null) {
      final isLocked = await _lockService.isAppLockEnabled();
      state = state.copyWith(
        user: UserProfile(
          uid: currentFirebaseUser.uid,
          email: currentFirebaseUser.email ?? '',
          name: currentFirebaseUser.displayName ?? 'MART User',
          photoURL: currentFirebaseUser.photoURL,
        ),
        isLoading: false,
        isAppLocked: isLocked,
      );
    } else {
      state = state.copyWith(isLoading: false);
    }
  }

  Future<void> signInWithGoogle() async {
    state = state.copyWith(isLoading: true, blockedReason: null);
    try {
      final profile = await _authService.signInWithGoogle(
        onBlocked: (reason) {
          state = state.copyWith(
            isLoading: false,
            blockedReason: reason,
          );
        },
      );
      if (profile != null) {
        final isLocked = await _lockService.isAppLockEnabled();
        state = state.copyWith(
          user: profile,
          isLoading: false,
          isAppLocked: isLocked,
        );
      } else {
        state = state.copyWith(isLoading: false);
      }
    } catch (_) {
      state = state.copyWith(isLoading: false);
    }
  }

  void unlockApp() {
    state = state.copyWith(isAppLocked: false);
  }

  void lockApp() {
    state = state.copyWith(isAppLocked: true);
  }

  Future<void> signOut() async {
    await _authService.signOut();
    state = AuthState(isLoading: false);
  }
}

final authStateProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(
    ref.watch(authServiceProvider),
    ref.watch(appLockServiceProvider),
  );
});

// Organization Context Provider
final selectedOrgProvider = StateProvider<Organization?>((ref) => null);

// App Theme Provider
final appThemeProvider = StateProvider<AppThemeMode>((ref) => AppThemeMode.system);
