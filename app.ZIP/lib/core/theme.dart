import 'package:flutter/material.dart';

enum AppThemeMode {
  system,
  light,
  dark,
  highContrast,
  ocean,
  forest,
}

class AppThemes {
  static const String fontFamily = 'Inter';

  // Base Colors
  static const Color primaryNavy = Color(0xFF163A5F);
  static const Color primaryBlue = Color(0xFF245B88);
  static const Color secondaryTeal = Color(0xFF0D9488);
  static const Color forestGreen = Color(0xFF1B4332);
  static const Color oceanDeep = Color(0xFF0F3057);

  static ThemeData lightTheme() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: primaryNavy,
      brightness: Brightness.light,
      primary: primaryNavy,
      secondary: primaryBlue,
      surface: const Color(0xFFFFFFFF),
      onSurface: const Color(0xFF1E293B),
    );

    return ThemeData(
      useMaterial3: true,
      fontFamily: fontFamily,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: const Color(0xFFF7FAFD),
      cardTheme: CardTheme(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFFE2E8F0), width: 1),
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: Color(0xFF0F172A),
        elevation: 0,
        scrolledUnderElevation: 1,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Colors.white,
        indicatorColor: primaryNavy.withValues(alpha: 0.12),
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
        ),
      ),
    );
  }

  static ThemeData darkTheme() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: primaryBlue,
      brightness: Brightness.dark,
      primary: const Color(0xFF60A5FA),
      secondary: const Color(0xFF38BDF8),
      surface: const Color(0xFF182736),
      onSurface: const Color(0xFFF1F5F9),
    );

    return ThemeData(
      useMaterial3: true,
      fontFamily: fontFamily,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: const Color(0xFF0F1A24),
      cardTheme: CardTheme(
        color: const Color(0xFF182736),
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFF2B3D4F), width: 1),
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF182736),
        foregroundColor: Color(0xFFF8FAFC),
        elevation: 0,
        scrolledUnderElevation: 1,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFF182736),
        indicatorColor: const Color(0xFF2B3D4F),
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
        ),
      ),
    );
  }

  static ThemeData highContrastTheme() {
    return ThemeData(
      useMaterial3: true,
      fontFamily: fontFamily,
      brightness: Brightness.dark,
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFF38BDF8),
        secondary: Color(0xFFFBBF24),
        surface: Color(0xFF000000),
        onSurface: Color(0xFFFFFFFF),
      ),
      scaffoldBackgroundColor: const Color(0xFF000000),
      cardTheme: CardTheme(
        color: const Color(0xFF121212),
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Colors.white, width: 1.5),
        ),
      ),
    );
  }

  static ThemeData oceanTheme() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: oceanDeep,
      brightness: Brightness.light,
      primary: oceanDeep,
      secondary: const Color(0xFF008891),
      surface: const Color(0xFFFFFFFF),
    );

    return ThemeData(
      useMaterial3: true,
      fontFamily: fontFamily,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: const Color(0xFFE8F1F5),
      cardTheme: CardTheme(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFFCBD5E1), width: 1),
        ),
      ),
    );
  }

  static ThemeData forestTheme() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: forestGreen,
      brightness: Brightness.light,
      primary: forestGreen,
      secondary: const Color(0xFF40916C),
      surface: const Color(0xFFFFFFFF),
    );

    return ThemeData(
      useMaterial3: true,
      fontFamily: fontFamily,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: const Color(0xFFF3F7F4),
      cardTheme: CardTheme(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFFD1E7DD), width: 1),
        ),
      ),
    );
  }

  static ThemeData getTheme(AppThemeMode mode, Brightness systemBrightness) {
    switch (mode) {
      case AppThemeMode.light:
        return lightTheme();
      case AppThemeMode.dark:
        return darkTheme();
      case AppThemeMode.highContrast:
        return highContrastTheme();
      case AppThemeMode.ocean:
        return oceanTheme();
      case AppThemeMode.forest:
        return forestTheme();
      case AppThemeMode.system:
        return systemBrightness == Brightness.dark ? darkTheme() : lightTheme();
    }
  }
}
