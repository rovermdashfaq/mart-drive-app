import 'package:flutter/material.dart';

class ConfirmDialog {
  static Future<bool> show(
    BuildContext context, {
    required String title,
    required String message,
    String confirmLabel = 'Confirm',
    Color? confirmColor,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: confirmColor != null
                ? FilledButton.styleFrom(backgroundColor: confirmColor)
                : null,
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(confirmLabel),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  /// Specialized dialog matching web admin delete-user flow with the 2 checkboxes
  static Future<Map<String, bool>?> showDeleteUserDialog(
    BuildContext context, {
    required String userEmail,
  }) async {
    bool deleteData = true;
    bool blockUser = true;

    return await showDialog<Map<String, bool>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: Text('Delete User $userEmail'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Are you sure you want to delete this user? This action cannot be undone.',
                ),
                const SizedBox(height: 16),
                CheckboxListTile(
                  title: const Text('Also delete all their data'),
                  subtitle: const Text('Wipes files, notes, and permissions'),
                  value: deleteData,
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  onChanged: (val) => setState(() => deleteData = val ?? true),
                ),
                CheckboxListTile(
                  title: const Text('Block them as well'),
                  subtitle: const Text('Prevents future logins with this Google account'),
                  value: blockUser,
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  onChanged: (val) => setState(() => blockUser = val ?? true),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, null),
                child: const Text('Cancel'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFFEF4444)),
                onPressed: () => Navigator.pop(ctx, {
                  'confirmed': true,
                  'deleteData': deleteData,
                  'blockUser': blockUser,
                }),
                child: const Text('Delete Permanently'),
              ),
            ],
          );
        },
      ),
    );
  }
}
