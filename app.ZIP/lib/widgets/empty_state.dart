import 'package:flutter/material.dart';

class EmptyStateWidget extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;

  const EmptyStateWidget({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.actionLabel,
    this.onAction,
  });

  factory EmptyStateWidget.forView(String viewName, {VoidCallback? onAction}) {
    switch (viewName) {
      case 'trash':
        return EmptyStateWidget(
          icon: Icons.delete_outline_rounded,
          title: 'Trash is empty',
          subtitle: 'Items moved to trash will appear here for 30 days before being permanently deleted.',
        );
      case 'starred':
        return EmptyStateWidget(
          icon: Icons.star_border_rounded,
          title: 'No starred items',
          subtitle: 'Star important files, folders, and notes for fast one-tap access.',
        );
      case 'recent':
        return EmptyStateWidget(
          icon: Icons.access_time_rounded,
          title: 'No recent activity',
          subtitle: 'Files you upload or view recently will show up right here.',
        );
      case 'notes':
        return EmptyStateWidget(
          icon: Icons.edit_note_rounded,
          title: 'No notes or links yet',
          subtitle: 'Capture quick meeting notes, rich links, and ideas with live collaboration.',
          actionLabel: 'Create Note',
          onAction: onAction,
        );
      case 'drive':
        return EmptyStateWidget(
          icon: Icons.folder_open_rounded,
          title: 'This folder is empty',
          subtitle: 'Upload files or create subfolders to organize your team documents.',
          actionLabel: 'Upload File',
          onAction: onAction,
        );
      case 'shared':
        return EmptyStateWidget(
          icon: Icons.people_outline_rounded,
          title: 'No shared files',
          subtitle: 'Files and folders shared with you or by you will appear here.',
        );
      case 'vault':
        return EmptyStateWidget(
          icon: Icons.shield_outlined,
          title: 'Vault is empty',
          subtitle: 'Move sensitive files or private notes into the vault for PIN-protected security.',
        );
      default:
        return EmptyStateWidget(
          icon: Icons.cloud_queue_rounded,
          title: 'No files yet',
          subtitle: 'Your workspace is empty. Start by uploading files or creating an organization.',
          actionLabel: 'Add File',
          onAction: onAction,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 48.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: theme.colorScheme.primary.withValues(alpha: 0.08),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                size: 48,
                color: theme.colorScheme.primary,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              title,
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w700,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.65),
                height: 1.4,
              ),
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: onAction,
                icon: const Icon(Icons.add, size: 18),
                label: Text(actionLabel!),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
