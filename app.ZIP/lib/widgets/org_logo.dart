import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/organization.dart';

class OrgLogo extends StatelessWidget {
  final Organization? org;
  final double size;

  const OrgLogo({
    super.key,
    required this.org,
    this.size = 36,
  });

  @override
  Widget build(BuildContext context) {
    if (org == null) {
      // Personal Drive
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: const Color(0xFF163A5F).withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Icon(
          Icons.person_rounded,
          size: size * 0.6,
          color: const Color(0xFF163A5F),
        ),
      );
    }

    Widget content;
    if (org!.logoUrl != null && org!.logoUrl!.isNotEmpty) {
      content = ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: CachedNetworkImage(
          imageUrl: org!.logoUrl!,
          width: size,
          height: size,
          fit: BoxFit.cover,
          placeholder: (_, __) => Container(
            color: const Color(0xFF163A5F).withValues(alpha: 0.1),
          ),
          errorWidget: (_, __, ___) => _fallbackLetter(),
        ),
      );
    } else {
      content = _fallbackLetter();
    }

    if (org!.isPremium) {
      return Stack(
        clipBehavior: Clip.none,
        children: [
          content,
          Positioned(
            right: -4,
            top: -6,
            child: Container(
              padding: const EdgeInsets.all(2),
              decoration: const BoxDecoration(
                color: Color(0xFFF59E0B),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.workspace_premium_rounded,
                size: 11,
                color: Colors.white,
              ),
            ),
          ),
        ],
      );
    }

    return content;
  }

  Widget _fallbackLetter() {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xFF245B88),
        borderRadius: BorderRadius.circular(6),
      ),
      alignment: Alignment.center,
      child: Text(
        org!.name.isNotEmpty ? org!.name[0].toUpperCase() : 'O',
        style: TextStyle(
          color: Colors.white,
          fontSize: size * 0.5,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
