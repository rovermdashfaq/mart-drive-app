import 'package:flutter/material.dart';

class DriveHelper {
  /// Resolves icon for file mime type
  static IconData getIconForMime(String mimeType) {
    if (mimeType.startsWith('image/')) return Icons.image_rounded;
    if (mimeType.startsWith('video/')) return Icons.videocam_rounded;
    if (mimeType.startsWith('audio/')) return Icons.audiotrack_rounded;
    if (mimeType == 'application/pdf') return Icons.picture_as_pdf_rounded;
    if (mimeType.contains('word') || mimeType.contains('document')) return Icons.description_rounded;
    if (mimeType.contains('sheet') || mimeType.contains('excel')) return Icons.table_chart_rounded;
    if (mimeType.contains('presentation') || mimeType.contains('powerpoint')) return Icons.slideshow_rounded;
    if (mimeType.contains('zip') || mimeType.contains('tar') || mimeType.contains('compressed')) {
      return Icons.folder_zip_rounded;
    }
    if (mimeType.startsWith('text/') || mimeType.contains('json') || mimeType.contains('javascript')) {
      return Icons.code_rounded;
    }
    return Icons.insert_drive_file_rounded;
  }

  /// Categorizes MIME type for previews
  static String categorizeMime(String mimeType) {
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('video/')) return 'video';
    if (mimeType.startsWith('audio/')) return 'audio';
    if (mimeType == 'application/pdf') return 'pdf';
    if (mimeType.contains('word') ||
        mimeType.contains('sheet') ||
        mimeType.contains('presentation') ||
        mimeType.contains('officedocument')) {
      return 'office';
    }
    if (mimeType.startsWith('text/') || mimeType.contains('json') || mimeType.contains('code')) {
      return 'code';
    }
    return 'generic';
  }
}
