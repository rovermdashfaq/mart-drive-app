import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;

class AppFormatters {
  /// Format byte size into readable string (B, KB, MB, GB, TB)
  static String fmtSize(int bytes) {
    if (bytes <= 0) return '0 B';
    const suffixes = ['B', 'KB', 'MB', 'GB', 'TB'];
    int i = 0;
    double d = bytes.toDouble();
    while (d >= 1024 && i < suffixes.length - 1) {
      d /= 1024;
      i++;
    }
    return '${d.toStringAsFixed(d < 10 && i > 0 ? 1 : 0)} ${suffixes[i]}';
  }

  /// Format DateTime into relative time ("2 hours ago")
  static String ago(DateTime? dateTime) {
    if (dateTime == null) return 'Never';
    return timeago.format(dateTime);
  }

  /// Format DateTime into readable standard date
  static String date(DateTime? dateTime, {bool includeTime = false}) {
    if (dateTime == null) return '';
    if (includeTime) {
      return DateFormat('MMM d, yyyy · h:mm a').format(dateTime);
    }
    return DateFormat('MMM d, yyyy').format(dateTime);
  }
}
