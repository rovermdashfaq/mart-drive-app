import 'dart:convert';
import 'package:http/http.dart' as http;

class GeoHelper {
  /// Fetches the user's current country code or name via IP lookup
  static Future<String?> getCurrentCountry() async {
    try {
      final res = await http.get(Uri.parse('https://ipwho.is/')).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data['country'] as String?;
      }
    } catch (_) {
      try {
        final res2 = await http.get(Uri.parse('https://ipapi.co/country_name/')).timeout(const Duration(seconds: 4));
        if (res2.statusCode == 200) {
          return res2.body.trim();
        }
      } catch (_) {}
    }
    return null;
  }
}
