class EmailUtils {
  static final RegExp emailRegex = RegExp(
    r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$",
  );

  /// Validates a single email address
  static bool isValid(String email) {
    return emailRegex.hasMatch(email.trim());
  }

  /// Parses comma, space or newline separated email list
  static List<String> parseEmails(String input) {
    return input
        .split(RegExp(r'[,;\s]+'))
        .map((e) => e.trim().toLowerCase())
        .where((e) => e.isNotEmpty && isValid(e))
        .toSet()
        .toList();
  }
}
