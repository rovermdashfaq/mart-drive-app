# MART Drive — Flutter Mobile Application

A production-ready, native mobile application for **MART Drive** (iOS & Android) built with **Flutter 3.24+**, **Dart 3.5+**, and **Riverpod 2.x**.

MART Drive connects directly to the **SAME** Firebase Firestore database, Google Drive backend, and authentication service as the live website at [https://mart-drive.vercel.app](https://mart-drive.vercel.app). Changes made in either the mobile app or web app sync in real-time.

---

## 📱 Features

- **Native Material 3 + Cupertino Experience**: Dynamic theming (System, Light, Dark, High Contrast, Ocean, Forest) using Inter typography.
- **Shared Firestore Schema**: Exact 1:1 mapping with the existing web app (`users`, `files`, `folders`, `notes`, `organizations`, `shares`, `userSessions`, `userSecurity`).
- **Google Drive API Integration**:
  - Multipart upload (`POST /upload/drive/v3/files?uploadType=multipart`).
  - Resumable chunked file downloads with download progress bars.
  - Reader/writer permission granting to organization members.
  - Storage quota tracking (`/drive/v3/about?fields=storageQuota`).
- **Live Collaborative Notes**: Exact Dart port of the web app's `m3` 3-way merge algorithm with character span detection and non-destructive conflict handling.
- **Biometric App Lock & PIN**: PBKDF2-SHA256 (150,000 iterations) with exponential brute-force backoff and Face ID / Fingerprint via `local_auth`.
- **Encrypted Vault**: Isolated view with separate PIN in `userSecurity/{uid}.vault`, 5-minute inactivity auto-lock, and sharing restrictions.
- **Multi-tenant Organizations**: Switch seamlessly between Personal Drive and team workspaces, with 10+ member gold premium look and role-based permissions (`roleOf` & `menuFor`).
- **Deep Linking**: Handles `martdrive://` custom schemes and `https://mart-drive.vercel.app/` Android App Links / Universal Links.

---

## 🗺️ Web App to Flutter App Mapping Table

| Web App Feature / Function (`mart-drive.vercel.app`) | Flutter App Location (`lib/`) | Description |
|---|---|---|
| Main files list & chips (`view: all, starred, recent`) | `lib/features/files/all_files_screen.dart` | Segmented chips, grid/list toggle, bulk action bar |
| Drive folder tree & breadcrumbs | `lib/features/files/drive_screen.dart` | Folder drill-down, organization switcher, storage quota |
| File Card & List Tiles | `lib/features/files/file_card.dart`, `list_tile.dart` | Thumbnails, star toggle, uploader, org tags |
| Context Menu (`MENUS` map & role filter) | `lib/features/files/context_menu.dart` | `menuFor()` enforcement matching exact permissions |
| Live Note Editor & `m3` 3-Way Merge | `lib/features/notes/live_note_editor.dart` | Realtime collaborative text with conflict restoration |
| Link Bookmarks (`fetchPreview`) | `lib/features/notes/link_editor.dart` | Microlink + WordPress mshots live preview cards |
| Multi-tenant Org Switcher & Premium Look | `lib/features/organizations/org_switcher.dart` | 10+ member gold crown, founder/owner/member hierarchy |
| Organization Management & Join Requests | `lib/features/organizations/org_manage_screen.dart` | Promote/demote, QR code invites, auto-approve |
| Share Links & QR Generator (`makeQR`) | `lib/features/share_links/share_link_dialog.dart` | Expiry (1d/7d/30d), password hashing, QR with logo |
| App Lock & Biometrics (`SEC:core`) | `lib/services/app_lock_service.dart` | PBKDF2-SHA256 (150k iter), secure storage |
| Secure Vault (`userSecurity/{uid}.vault`) | `lib/features/vault/vault_screen.dart` | Isolated PIN, 5-min auto-lock, vault filter |
| Device Sessions (`userSessions/{uid_sid}`) | `lib/services/session_service.dart` | 3-minute heartbeat, revocation stream listener |
| Admin Panel | `lib/features/profile/profile_screen.dart` | Embedded WebView for Super Admin / Admin emails |

---

## 🚀 Setup & Installation

### Prerequisites
- Flutter SDK `>=3.24.0` (Dart `>=3.5.0`)
- Android Studio / Xcode
- Git

### 1. Clone & Fetch Dependencies
```bash
git clone <repository_url>
cd mart-drive-mobile
flutter pub get
```

### 2. Configure Firebase Credentials
The app uses the existing Firebase project `mart-drive`.
- The configuration is pre-configured in `lib/firebase_options.dart`.
- Android: Ensure `android/app/google-services.json` is present.
- iOS: Ensure `ios/Runner/GoogleService-Info.plist` is present.

### 3. Run the Application
```bash
# Run on connected Android / iOS device or emulator
flutter run
```

---

## 🏢 Adding a New Organization

1. Open the **Drive** tab in the app.
2. In the organization horizontal chip scroller, tap **"New Org"** (or use the central **Create (+)** button → **"Create Organization"**).
3. Fill in the Organization Name, Team Name, and optional Logo URL (or upload via camera/gallery to ImgBB).
4. The organization will be created in `organizations/{id}` with the current user set in `founders[]`, `owners[]`, and `members[]`.
5. Share the generated invite code or QR code (`martdrive://join/<code>`).

---

## 🔒 Security Architecture

- **App Lock**: Passcode salted with 16 random bytes and hashed using PBKDF2 with 150,000 iterations. Stored exclusively in hardware-backed secure storage (`KeyStore` on Android, `Keychain` on iOS).
- **Brute-force Throttle**: After 5 failed attempts, the app enforces a 30-second cooldown, doubling up to 15 minutes.
- **Forgot PIN Flow**: Validates identity by triggering Google re-authentication.
- **Remote Revocation**: Every device session is recorded in `userSessions/{uid_sid}`. If a session is marked `revoked: true` from another device, the local app immediately terminates the session and signs out.

---

## 🔄 Real-time Synchronization (Migration Notes)

> **Important**: This mobile application does **NOT** use a separate database. It writes to and reads from the live Firestore database and Google Drive storage used by `https://mart-drive.vercel.app/`.
> 
> - Uploading a file from Android or iOS writes directly to Google Drive and adds a document to `files/{id}`. The live website updates instantly via its Firestore listener.
> - Editing a note in the mobile editor runs transactions through `m3()` merging alongside web collaborators in real time.
> - Banning a user or deleting a session from the Admin Panel instantly locks the mobile client out.
