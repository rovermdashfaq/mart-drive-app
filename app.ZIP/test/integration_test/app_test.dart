import 'package:flutter_test/flutter_test.dart';
import 'package:mart_drive/services/merge_service.dart';

void main() {
  group('MART Drive Core Integration & Algorithm Tests', () {
    test('m3 3-way merge correctly preserves disjoint edits', () {
      const base = 'Header\n\nSection 1\n\nSection 2\n\nFooter';
      const mine = 'Header (Modified)\n\nSection 1\n\nSection 2\n\nFooter';
      const server = 'Header\n\nSection 1\n\nSection 2 (Server Update)\n\nFooter';

      final result = MergeService.m3(base, mine, server);
      expect(result.hasConflict, isFalse);
      expect(result.text.contains('Header (Modified)'), isTrue);
      expect(result.text.contains('Section 2 (Server Update)'), isTrue);
    });

    test('m3 3-way merge flags overlapping conflicting edits', () {
      const base = 'The quick brown fox';
      const mine = 'The rapid brown fox';
      const server = 'The fast brown fox';

      final result = MergeService.m3(base, mine, server);
      expect(result.hasConflict, isTrue);
      expect(result.conflictText, equals('The rapid brown fox'));
      expect(result.text, equals('The fast brown fox')); // Server version retained per policy
    });

    test('Span common prefix and suffix detection', () {
      final span = MergeService.span('hello world', 'hello everyone world');
      expect(span.prefix, equals(6)); // "hello "
      expect(span.suffix, equals(5)); // "world"
    });
  });
}
