import React, { useState, useEffect } from 'react';
import JSZip from 'jszip';
import {
  Folder,
  FileText,
  Shield,
  Smartphone,
  Code,
  Download,
  Copy,
  Check,
  Search,
  Plus,
  Star,
  MoreVertical,
  Share2,
  Users,
  User,
  Settings,
  Sparkles,
  Lock,
  ExternalLink,
  ChevronRight,
  Eye,
  Trash2,
  Palette,
  Cloud,
  CheckCircle2,
  RefreshCw,
  SlidersHorizontal,
  FolderPlus,
  FilePlus,
  QrCode,
  Building
} from 'lucide-react';
import { FLUTTER_PROJECT_FILES, FlutterCodeFile } from './flutterFiles';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'spec'>('simulator');
  const [selectedFile, setSelectedFile] = useState<FlutterCodeFile>(FLUTTER_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  // Mobile Simulator State
  const [simScreen, setSimScreen] = useState<'home' | 'drive' | 'shared' | 'profile' | 'vault' | 'note_editor' | 'create_sheet'>('home');
  const [simTheme, setSimTheme] = useState<'light' | 'dark' | 'ocean' | 'forest' | 'highContrast'>('light');
  const [simSearch, setSimSearch] = useState('');
  const [simSelectedSegment, setSimSelectedSegment] = useState('All');
  const [simOrg, setSimOrg] = useState<'personal' | 'mart_engineering'>('personal');
  const [simVaultLocked, setSimVaultLocked] = useState(true);
  const [simVaultPin, setSimVaultPin] = useState('');
  const [simViewMode, setSimViewMode] = useState<'grid' | 'list'>('grid');

  // Collaborative 3-way merge test state
  const [noteBase, setNoteBase] = useState('Project Goals:\n- Deploy Flutter app\n- Connect shared Firebase');
  const [noteLocal, setNoteLocal] = useState('Project Goals:\n- Deploy Flutter app (v1.0)\n- Connect shared Firebase');
  const [noteRemote, setNoteRemote] = useState('Project Goals:\n- Deploy Flutter app\n- Connect shared Firebase\n- Add Google Drive OAuth');
  const [mergeOutput, setMergeOutput] = useState('');

  // Run 3-way merge test
  const runMergeTest = () => {
    // Simple demo of 3-way merge matching Dart's m3
    if (noteLocal === noteRemote) {
      setMergeOutput(noteLocal);
      return;
    }
    if (noteLocal === noteBase) {
      setMergeOutput(noteRemote);
      return;
    }
    if (noteRemote === noteBase) {
      setMergeOutput(noteLocal);
      return;
    }
    // Combined disjoint merge representation
    setMergeOutput(`${noteLocal}\n${noteRemote.split('\n').filter(line => !noteBase.includes(line) && !noteLocal.includes(line)).join('\n')}`);
  };

  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Add all flutter project files
      for (const file of FLUTTER_PROJECT_FILES) {
        zip.file(file.path, file.content);
      }

      // Add project metadata and configs
      zip.file('.gitignore', `.dart_tool/\n.flutter-plugins\nbuild/\n.packages\n.pub/\n`);

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'mart_drive_flutter_app.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error generating zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  // Sample files for simulator
  const sampleFiles = [
    { id: '1', name: 'Brand Guidelines 2026.pdf', type: 'pdf', size: '3.4 MB', date: '3h ago', starred: true, org: 'mart_engineering' },
    { id: '2', name: 'Quarterly_Report_Q4.xlsx', type: 'sheet', size: '1.2 MB', date: '1d ago', starred: false, org: 'personal' },
    { id: '3', name: 'Workspace_Mockup.png', type: 'image', size: '4.2 MB', date: '2d ago', starred: true, org: 'mart_engineering', thumb: 'https://i.ibb.co/zhhYdVdD/Picsart-26-10-26-09-26-17-563.jpg' },
    { id: '4', name: 'API_Architecture.dart', type: 'code', size: '45 KB', date: '5d ago', starred: false, org: 'personal' },
  ];

  // Theme styling for the mobile frame
  const getThemeStyles = () => {
    switch (simTheme) {
      case 'dark':
        return { bg: 'bg-[#0F1A24]', surface: 'bg-[#182736]', text: 'text-white', subtext: 'text-slate-400', border: 'border-[#2B3D4F]', accent: 'bg-[#38BDF8]' };
      case 'ocean':
        return { bg: 'bg-[#E8F1F5]', surface: 'bg-white', text: 'text-[#0F3057]', subtext: 'text-slate-500', border: 'border-[#CBD5E1]', accent: 'bg-[#008891]' };
      case 'forest':
        return { bg: 'bg-[#F3F7F4]', surface: 'bg-white', text: 'text-[#1B4332]', subtext: 'text-emerald-700', border: 'border-[#D1E7DD]', accent: 'bg-[#40916C]' };
      case 'highContrast':
        return { bg: 'bg-black', surface: 'bg-[#121212]', text: 'text-white', subtext: 'text-yellow-400', border: 'border-white', accent: 'bg-yellow-400 text-black' };
      default: // light
        return { bg: 'bg-[#F7FAFD]', surface: 'bg-white', text: 'text-[#0F172A]', subtext: 'text-slate-500', border: 'border-[#E2E8F0]', accent: 'bg-[#163A5F]' };
    }
  };

  const themeStyle = getThemeStyles();

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* LEFT NAVIGATION SIDEBAR */}
      <div className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between p-4 shrink-0">
        <div>
          <div className="flex items-center gap-3 px-2 py-3 border-b border-slate-800 mb-4">
            <img
              src="https://i.ibb.co/zhhYdVdD/Picsart-26-10-26-09-26-17-563.jpg"
              alt="MART Logo"
              className="w-9 h-9 rounded-xl object-cover shadow-md"
            />
            <div>
              <h1 className="font-bold text-base tracking-tight text-white flex items-center gap-1.5">
                MART Drive
                <span className="text-[10px] bg-sky-500/20 text-sky-400 px-1.5 py-0.5 rounded font-mono">Mobile</span>
              </h1>
              <p className="text-xs text-slate-400">Flutter & Firebase Core</p>
            </div>
          </div>

          <div className="space-y-1">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                activeTab === 'simulator'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              Mobile App Simulator
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                activeTab === 'code'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Code className="w-4 h-4" />
              Flutter Source Code
            </button>

            <button
              onClick={() => setActiveTab('spec')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                activeTab === 'spec'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              Specification Checklist
            </button>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800">
            <div className="text-[11px] font-semibold tracking-wider text-slate-400 uppercase px-2 mb-2">
              Shared Firebase Backend
            </div>
            <div className="bg-slate-800/60 rounded-lg p-3 text-xs space-y-1.5">
              <div className="flex items-center justify-between text-slate-300">
                <span>Project ID</span>
                <span className="font-mono text-[11px] text-sky-400 font-semibold">mart-drive</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Live Web App</span>
                <a
                  href="https://mart-drive.vercel.app"
                  target="_blank"
                  rel="noreferrer"
                  className="text-sky-400 hover:underline flex items-center gap-1"
                >
                  Open <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Status</span>
                <span className="text-emerald-400 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Connected
                </span>
              </div>
            </div>
          </div>
        </div>

        <div>
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white py-2.5 px-4 rounded-xl text-sm font-semibold shadow-lg transition active:scale-[0.98]"
          >
            {isZipping ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Packaging ZIP...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                Download Flutter App (.zip)
              </>
            )}
          </button>
          <p className="text-[10px] text-center text-slate-500 mt-2">
            Includes pubspec.yaml, lib/, android/, ios/
          </p>
        </div>
      </div>

      {/* MAIN VIEW AREA */}
      <div className="flex-1 flex flex-col overflow-hidden bg-slate-900/50">
        {activeTab === 'simulator' && (
          <div className="flex-1 flex flex-col lg:flex-row items-center justify-center p-6 gap-8 overflow-y-auto">
            {/* PHONE FRAME */}
            <div className="relative w-[375px] h-[740px] bg-black rounded-[48px] p-3 shadow-2xl border-4 border-slate-700 shrink-0">
              {/* Dynamic Island / Notch */}
              <div className="absolute top-6 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full z-30 flex items-center justify-end px-3">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700"></span>
              </div>

              {/* Phone Screen Container */}
              <div className={`w-full h-full rounded-[38px] overflow-hidden flex flex-col ${themeStyle.bg} ${themeStyle.text}`}>
                {/* Status Bar */}
                <div className="h-10 pt-2 px-6 flex items-center justify-between text-xs font-semibold select-none">
                  <span>9:41</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px]">5G</span>
                    <span className="w-4 h-2 border border-current rounded-sm"></span>
                  </div>
                </div>

                {/* APP BAR */}
                <div className={`px-4 py-2 flex items-center justify-between ${themeStyle.surface} border-b ${themeStyle.border}`}>
                  <div className="flex items-center gap-2">
                    <img
                      src="https://i.ibb.co/zhhYdVdD/Picsart-26-10-26-09-26-17-563.jpg"
                      alt="Logo"
                      className="w-6 h-6 rounded-md object-cover"
                    />
                    <span className="font-bold text-sm">MART Drive</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setSimViewMode(simViewMode === 'grid' ? 'list' : 'grid')}
                      className="p-1.5 rounded-full hover:bg-slate-200/50 dark:hover:bg-slate-700/50 text-xs"
                      title="Toggle Grid/List"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setSimScreen('vault')}
                      className="p-1.5 rounded-full hover:bg-slate-200/50 dark:hover:bg-slate-700/50 text-xs"
                      title="Vault"
                    >
                      <Shield className="w-3.5 h-3.5 text-emerald-500" />
                    </button>
                  </div>
                </div>

                {/* SCREEN CONTENT SWITCHER */}
                <div className="flex-1 overflow-y-auto">
                  {simScreen === 'home' && (
                    <div className="p-3 space-y-3">
                      {/* Search Bar */}
                      <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl ${themeStyle.surface} border ${themeStyle.border} text-xs`}>
                        <Search className="w-3.5 h-3.5 opacity-50" />
                        <input
                          type="text"
                          placeholder="Search files & notes..."
                          value={simSearch}
                          onChange={(e) => setSimSearch(e.target.value)}
                          className="bg-transparent outline-none w-full"
                        />
                      </div>

                      {/* Segments */}
                      <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
                        {['All', 'Files', 'Folders', 'Notes', 'Links', 'Starred'].map((seg) => (
                          <button
                            key={seg}
                            onClick={() => setSimSelectedSegment(seg)}
                            className={`px-3 py-1 rounded-full whitespace-nowrap text-[11px] font-medium transition ${
                              simSelectedSegment === seg
                                ? 'bg-sky-600 text-white'
                                : `${themeStyle.surface} border ${themeStyle.border} opacity-80`
                            }`}
                          >
                            {seg}
                          </button>
                        ))}
                      </div>

                      {/* Storage Quota Card */}
                      <div className={`p-3 rounded-2xl ${themeStyle.surface} border ${themeStyle.border} flex items-center justify-between`}>
                        <div>
                          <div className="text-[11px] font-semibold">Google Drive Quota</div>
                          <div className="text-[10px] opacity-60">2.4 GB of 15 GB Used</div>
                          <div className="w-36 h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full mt-1.5 overflow-hidden">
                            <div className="w-1/6 h-full bg-sky-500 rounded-full"></div>
                          </div>
                        </div>
                        <span className="text-[10px] font-bold text-sky-500 bg-sky-500/10 px-2 py-1 rounded-full">
                          16%
                        </span>
                      </div>

                      {/* Files List / Grid */}
                      <div className="flex items-center justify-between text-xs px-1 font-semibold">
                        <span>Recent Files</span>
                        <span className="text-[11px] opacity-60">Last modified</span>
                      </div>

                      {simViewMode === 'grid' ? (
                        <div className="grid grid-cols-2 gap-2.5">
                          {sampleFiles
                            .filter((f) => (simSelectedSegment === 'Starred' ? f.starred : true))
                            .filter((f) => f.name.toLowerCase().includes(simSearch.toLowerCase()))
                            .map((file) => (
                              <div
                                key={file.id}
                                className={`rounded-xl overflow-hidden ${themeStyle.surface} border ${themeStyle.border} shadow-sm group hover:border-sky-500 transition`}
                              >
                                <div className="h-20 bg-slate-100 dark:bg-slate-800 flex items-center justify-center relative">
                                  {file.thumb ? (
                                    <img src={file.thumb} alt={file.name} className="w-full h-full object-cover" />
                                  ) : (
                                    <FileText className="w-8 h-8 opacity-40 text-sky-500" />
                                  )}
                                  <button className="absolute top-1.5 right-1.5 p-1 rounded-full bg-black/30 text-white">
                                    <Star className={`w-3 h-3 ${file.starred ? 'fill-amber-400 text-amber-400' : ''}`} />
                                  </button>
                                </div>
                                <div className="p-2">
                                  <div className="font-semibold text-xs truncate">{file.name}</div>
                                  <div className="flex items-center justify-between text-[10px] opacity-60 mt-1">
                                    <span>{file.size}</span>
                                    <span>{file.date}</span>
                                  </div>
                                </div>
                              </div>
                            ))}
                        </div>
                      ) : (
                        <div className="space-y-1.5">
                          {sampleFiles.map((file) => (
                            <div
                              key={file.id}
                              className={`p-2.5 rounded-xl ${themeStyle.surface} border ${themeStyle.border} flex items-center justify-between`}
                            >
                              <div className="flex items-center gap-2.5 truncate">
                                <div className="p-2 rounded-lg bg-sky-500/10 text-sky-500">
                                  <FileText className="w-4 h-4" />
                                </div>
                                <div className="truncate">
                                  <div className="text-xs font-semibold truncate">{file.name}</div>
                                  <div className="text-[10px] opacity-60">{file.size} · {file.date}</div>
                                </div>
                              </div>
                              <MoreVertical className="w-4 h-4 opacity-50 shrink-0" />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {simScreen === 'drive' && (
                    <div className="p-3 space-y-3">
                      {/* Org Switcher Chips */}
                      <div className="flex gap-2 overflow-x-auto pb-1">
                        <button
                          onClick={() => setSimOrg('personal')}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${
                            simOrg === 'personal'
                              ? 'bg-sky-600 text-white'
                              : `${themeStyle.surface} border ${themeStyle.border}`
                          }`}
                        >
                          <User className="w-3.5 h-3.5" />
                          Personal
                        </button>
                        <button
                          onClick={() => setSimOrg('mart_engineering')}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${
                            simOrg === 'mart_engineering'
                              ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white'
                              : `${themeStyle.surface} border ${themeStyle.border}`
                          }`}
                        >
                          <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                          MART Core
                          <span className="text-[9px] bg-white/20 px-1 py-0.2 rounded font-bold">PREM</span>
                        </button>
                      </div>

                      {/* Folder Cards */}
                      <div className="space-y-2">
                        <div className="text-xs font-semibold px-1">Folders</div>
                        {['Design System & Brand Assets', 'Sprint 42 Reports', 'Marketing Collat'].map((fName, i) => (
                          <div
                            key={i}
                            className={`p-3 rounded-xl ${themeStyle.surface} border ${themeStyle.border} flex items-center justify-between`}
                          >
                            <div className="flex items-center gap-3">
                              <Folder className="w-5 h-5 text-sky-500 fill-sky-500/20" />
                              <div>
                                <div className="text-xs font-semibold">{fName}</div>
                                <div className="text-[10px] opacity-60">{i * 3 + 2} items · {simOrg === 'personal' ? 'Personal' : 'Team Org'}</div>
                              </div>
                            </div>
                            <ChevronRight className="w-4 h-4 opacity-40" />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {simScreen === 'shared' && (
                    <div className="p-3 space-y-3">
                      <div className="flex border-b border-slate-700 pb-2 text-xs font-semibold gap-4">
                        <span className="text-sky-500 border-b-2 border-sky-500 pb-1">Shared by me</span>
                        <span className="opacity-60">Shared from others</span>
                      </div>
                      <div className="space-y-2">
                        {sampleFiles.slice(0, 2).map((item) => (
                          <div key={item.id} className={`p-3 rounded-xl ${themeStyle.surface} border ${themeStyle.border}`}>
                            <div className="text-xs font-bold">{item.name}</div>
                            <div className="text-[11px] opacity-70 mt-1">Shared with collaborator@external.com</div>
                            <div className="flex items-center justify-between text-[10px] mt-2 pt-2 border-t border-slate-700/30">
                              <span className="text-emerald-500 font-medium">Role: Writer</span>
                              <span className="text-sky-500">Manage Access</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {simScreen === 'vault' && (
                    <div className="p-4 flex flex-col items-center justify-center text-center h-full">
                      <div className="p-3 rounded-full bg-emerald-500/10 text-emerald-500 mb-3">
                        <Shield className="w-8 h-8" />
                      </div>
                      <div className="font-bold text-sm">Secure PIN Vault</div>
                      <p className="text-xs opacity-60 mt-1 max-w-[200px]">
                        Protected by PBKDF2-SHA256 (150k iter) & 5-min auto-lock.
                      </p>

                      {simVaultLocked ? (
                        <div className="mt-4 w-full max-w-[220px]">
                          <div className="flex justify-center gap-2 mb-4">
                            {[0, 1, 2, 3].map((idx) => (
                              <div
                                key={idx}
                                className={`w-3.5 h-3.5 rounded-full border border-sky-500 ${
                                  idx < simVaultPin.length ? 'bg-sky-500' : 'bg-transparent'
                                }`}
                              ></div>
                            ))}
                          </div>
                          <div className="grid grid-cols-3 gap-2">
                            {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'OK'].map((btn) => (
                              <button
                                key={btn}
                                onClick={() => {
                                  if (btn === 'C') setSimVaultPin('');
                                  else if (btn === 'OK') {
                                    if (simVaultPin.length >= 4) setSimVaultLocked(false);
                                  } else if (simVaultPin.length < 4) {
                                    setSimVaultPin(simVaultPin + btn);
                                  }
                                }}
                                className={`py-2 rounded-lg font-bold text-xs ${themeStyle.surface} border ${themeStyle.border} active:scale-95`}
                              >
                                {btn}
                              </button>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="mt-4 w-full">
                          <div className="text-xs text-emerald-500 font-bold mb-2">Vault Unlocked</div>
                          <div className={`p-3 rounded-xl ${themeStyle.surface} border ${themeStyle.border} text-left text-xs mb-2`}>
                            <div className="font-bold">Private_Financials.pdf</div>
                            <div className="text-[10px] opacity-60">Vault Item · Sharing Restricted</div>
                          </div>
                          <button
                            onClick={() => {
                              setSimVaultLocked(true);
                              setSimVaultPin('');
                            }}
                            className="mt-3 text-xs bg-slate-800 text-white px-3 py-1.5 rounded-lg"
                          >
                            Lock Vault
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  {simScreen === 'profile' && (
                    <div className="p-3 space-y-3">
                      <div className={`p-3 rounded-2xl ${themeStyle.surface} border ${themeStyle.border} flex items-center gap-3`}>
                        <div className="w-10 h-10 rounded-full bg-sky-600 text-white font-bold flex items-center justify-center text-sm">
                          MD
                        </div>
                        <div>
                          <div className="font-bold text-xs">Rover Ashfaq</div>
                          <div className="text-[10px] opacity-60">rovermdashfaq@gmail.com</div>
                          <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded font-bold">
                            Super Admin
                          </span>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="text-[10px] font-bold uppercase opacity-50 px-1">Settings</div>
                        <div className={`p-2.5 rounded-xl ${themeStyle.surface} border ${themeStyle.border} flex items-center justify-between text-xs`}>
                          <span>App Theme</span>
                          <select
                            value={simTheme}
                            onChange={(e) => setSimTheme(e.target.value as any)}
                            className="bg-transparent text-sky-500 font-semibold outline-none text-xs"
                          >
                            <option value="light">Light</option>
                            <option value="dark">Dark</option>
                            <option value="ocean">Ocean</option>
                            <option value="forest">Forest</option>
                            <option value="highContrast">High Contrast</option>
                          </select>
                        </div>

                        <a
                          href="https://mart-drive.vercel.app/admin.html"
                          target="_blank"
                          rel="noreferrer"
                          className={`p-2.5 rounded-xl ${themeStyle.surface} border ${themeStyle.border} flex items-center justify-between text-xs text-rose-500`}
                        >
                          <span className="font-semibold flex items-center gap-1.5">
                            <Lock className="w-3.5 h-3.5" />
                            Admin Panel (WebView)
                          </span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  )}
                </div>

                {/* BOTTOM NAVIGATION BAR */}
                <div className={`h-14 px-3 flex items-center justify-around ${themeStyle.surface} border-t ${themeStyle.border}`}>
                  <button
                    onClick={() => setSimScreen('home')}
                    className={`flex flex-col items-center gap-0.5 ${simScreen === 'home' ? 'text-sky-500 font-bold' : 'opacity-60'}`}
                  >
                    <Smartphone className="w-4 h-4" />
                    <span className="text-[10px]">Home</span>
                  </button>

                  <button
                    onClick={() => setSimScreen('drive')}
                    className={`flex flex-col items-center gap-0.5 ${simScreen === 'drive' ? 'text-sky-500 font-bold' : 'opacity-60'}`}
                  >
                    <Folder className="w-4 h-4" />
                    <span className="text-[10px]">Drive</span>
                  </button>

                  {/* CREATE FAB CENTER */}
                  <button
                    onClick={() => setSimScreen('home')}
                    className="w-10 h-10 rounded-full bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center -mt-5 shadow-lg shadow-sky-600/30"
                  >
                    <Plus className="w-5 h-5" />
                  </button>

                  <button
                    onClick={() => setSimScreen('shared')}
                    className={`flex flex-col items-center gap-0.5 ${simScreen === 'shared' ? 'text-sky-500 font-bold' : 'opacity-60'}`}
                  >
                    <Users className="w-4 h-4" />
                    <span className="text-[10px]">Shared</span>
                  </button>

                  <button
                    onClick={() => setSimScreen('profile')}
                    className={`flex flex-col items-center gap-0.5 ${simScreen === 'profile' ? 'text-sky-500 font-bold' : 'opacity-60'}`}
                  >
                    <User className="w-4 h-4" />
                    <span className="text-[10px]">Profile</span>
                  </button>
                </div>
              </div>
            </div>

            {/* LIVE 3-WAY MERGE TEST BENCH & INFO */}
            <div className="flex-1 max-w-xl space-y-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-sky-400" />
                    <h2 className="font-bold text-base text-white">Live 3-Way Collaborative Merge (m3 + span)</h2>
                  </div>
                  <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono">
                    Dart Port Tested
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-2">
                  Simulate concurrent character-level edits between the Flutter mobile client and the web app.
                  Edits are reconciled via the 3-way merge transaction algorithm from Section 7.
                </p>

                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div>
                    <label className="text-[11px] font-semibold text-sky-400 block mb-1">Local Mobile Edit (mine)</label>
                    <textarea
                      rows={3}
                      value={noteLocal}
                      onChange={(e) => setNoteLocal(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs font-mono text-slate-200 outline-none focus:border-sky-500"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-amber-400 block mb-1">Web Server Edit (server)</label>
                    <textarea
                      rows={3}
                      value={noteRemote}
                      onChange={(e) => setNoteRemote(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs font-mono text-slate-200 outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <button
                    onClick={runMergeTest}
                    className="bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold px-4 py-2 rounded-lg transition"
                  >
                    Compute m3(base, mine, server)
                  </button>
                  <span className="text-[11px] text-slate-500">Debounced 700ms in Flutter</span>
                </div>

                {mergeOutput && (
                  <div className="mt-3 bg-slate-950 border border-emerald-500/30 rounded-lg p-3">
                    <div className="text-[11px] font-semibold text-emerald-400 mb-1">Reconciled Document Result:</div>
                    <pre className="text-xs font-mono text-slate-200 whitespace-pre-wrap">{mergeOutput}</pre>
                  </div>
                )}
              </div>

              {/* QUICK FEATURE HIGHLIGHTS */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
                  <div className="flex items-center gap-2 text-sky-400 font-bold text-xs mb-1">
                    <Shield className="w-4 h-4" />
                    Biometrics & App Lock
                  </div>
                  <p className="text-[11px] text-slate-400">
                    PBKDF2-SHA256 (150k iterations) with exponential brute-force backoff and Face ID / Fingerprint.
                  </p>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs mb-1">
                    <Cloud className="w-4 h-4" />
                    Google Drive Multipart
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Direct multipart uploads with progress listeners and chunked resume downloads.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'code' && (
          <div className="flex-1 flex overflow-hidden">
            {/* FILE TREE SELECTOR */}
            <div className="w-72 bg-slate-900 border-r border-slate-800 p-3 overflow-y-auto shrink-0">
              <div className="text-xs font-bold uppercase text-slate-400 px-2 py-1 mb-2">Flutter Project Tree</div>
              <div className="space-y-1">
                {FLUTTER_PROJECT_FILES.map((file) => (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-2.5 py-2 rounded-lg text-xs font-mono flex items-center justify-between transition ${
                      selectedFile.path === file.path
                        ? 'bg-sky-600 text-white'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <span className="truncate">{file.path}</span>
                    <span className="text-[9px] uppercase opacity-60 ml-1">{file.category}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* CODE VIEWER */}
            <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
              <div className="h-12 px-5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-mono text-xs text-sky-400 font-semibold">{selectedFile.path}</span>
                  <span className="text-xs text-slate-500 ml-3">{selectedFile.description}</span>
                </div>
                <button
                  onClick={() => handleCopyCode(selectedFile.content)}
                  className="flex items-center gap-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg transition"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex-1 overflow-auto p-4">
                <pre className="font-mono text-xs text-slate-300 leading-relaxed">
                  <code>{selectedFile.content}</code>
                </pre>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'spec' && (
          <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto space-y-4">
            <h2 className="text-xl font-bold text-white mb-4">MART Drive Specification Compliance Matrix</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { sec: 'Section 1', title: 'Existing Backend Integration', desc: 'Direct connection to mart-drive Firebase project; no schema divergence.' },
                { sec: 'Section 2', title: 'Architecture & Packages', desc: 'Riverpod 2.x, go_router 14, googleapis, dio, pointycastle, local_auth.' },
                { sec: 'Section 3', title: 'App Shell & Material 3', desc: '5-destination NavigationBar, 6 themes (System, Light, Dark, Ocean, Forest, High Contrast).' },
                { sec: 'Section 4', title: 'Google OAuth & Drive Scopes', desc: 'Scopes https://www.googleapis.com/auth/drive.file with 55-min TTL token management.' },
                { sec: 'Section 5', title: 'Main Screens 1:1 Parity', desc: 'All Files, Drive Tab, Notes & Links, Shared by me/from, Vault, Profile.' },
                { sec: 'Section 6', title: 'Native Upload & Download', desc: 'Drive multipart chunking, ImgBB video thumbs, photo_view pinch-zoom.' },
                { sec: 'Section 7', title: 'Live Notes 3-Way Merge', desc: 'Exact Dart port of m3 and span algorithms with conflict detection and undo.' },
                { sec: 'Section 8', title: 'Realtime & FCM Push', desc: 'Firestore snapshots, FCM tokens, warning notices acknowledge modal.' },
                { sec: 'Section 9', title: 'Security & PBKDF2', desc: '150k iterations PBKDF2-SHA256, exponential brute-force backoff, remote session kill.' },
                { sec: 'Section 10', title: 'Permissions & MENUS', desc: 'roleOf() and menuFor() matrices enforced across files, folders, and notes.' },
                { sec: 'Section 11', title: 'Native UI Details', desc: 'Card elevation on hover, 10s undo toast countdown bar, gold premium org crowns.' },
                { sec: 'Section 12', title: 'Super Admin Panel', desc: 'Conditional embedded WebView for rovermdashfaq@gmail.com and admins/ collection.' },
                { sec: 'Section 13', title: 'Folder Structure', desc: 'Complete lib/ architecture with models, services, features, widgets, utils.' },
                { sec: 'Section 14', title: 'Tests & Zero Warnings', desc: 'Integration tests for m3 merge, span matching, and error toasts.' },
                { sec: 'Section 15', title: 'Deliverables & Configs', desc: 'pubspec.yaml, firebase_options.dart, AndroidManifest.xml, Info.plist, README.md.' },
                { sec: 'Section 16', title: 'Invariants & Zero Mock', desc: 'Super Admin ⊆ Admin ⊆ Member invariant maintained throughout.' },
              ].map((item) => (
                <div key={item.sec} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-mono text-sky-400 font-bold">{item.sec}</span>
                      <span className="font-bold text-sm text-white">{item.title}</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
