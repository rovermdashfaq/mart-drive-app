// Repository map containing all Flutter project source files for inspection and 1-click ZIP export.

export interface FlutterCodeFile {
  path: string;
  category: 'core' | 'models' | 'services' | 'features' | 'widgets' | 'config' | 'tests';
  content: string;
  description: string;
}

export const FLUTTER_PROJECT_FILES: FlutterCodeFile[] = [
  {
    path: 'pubspec.yaml',
    category: 'config',
    description: 'Flutter dependencies (Riverpod 2.x, go_router 14, Firebase, Google APIs, local_auth, etc.)',
    content: `name: mart_drive
description: "MART Drive - Mobile app for MART Drive cloud workspace, files, notes, and team collaboration."
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.5.0 <4.0.0'
  flutter: '>=3.24.0'

dependencies:
  flutter:
    sdk: flutter

  firebase_core: ^3.6.0
  firebase_auth: ^5.3.1
  cloud_firestore: ^5.4.4
  firebase_messaging: ^15.1.3
  google_sign_in: ^6.2.1
  googleapis: ^13.2.0
  googleapis_auth: ^1.6.0
  http: ^1.2.2
  dio: ^5.7.0
  go_router: ^14.3.2
  flutter_riverpod: ^2.5.1
  cached_network_image: ^3.4.1
  photo_view: ^0.15.0
  flutter_svg: ^2.0.10+1
  flutter_staggered_grid_view: ^0.7.0
  shimmer: ^3.0.0
  file_picker: ^8.1.4
  image_picker: ^1.1.2
  flutter_image_compress: ^2.3.0
  image_cropper: ^8.0.2
  video_player: ^2.9.2
  chewie: ^1.8.5
  pdfx: ^2.6.0
  open_filex: ^4.5.0
  url_launcher: ^6.3.1
  flutter_html: ^3.0.0-beta.2
  flutter_highlight: ^0.7.0
  flutter_inappwebview: ^6.1.5
  shared_preferences: ^2.3.2
  flutter_secure_storage: ^9.2.2
  local_auth: ^2.2.0
  crypto: ^3.0.5
  pointycastle: ^3.9.1
  share_plus: ^10.1.2
  path_provider: ^2.1.4
  path: ^1.9.0
  intl: ^0.19.0
  timeago: ^3.7.0
  qr_flutter: ^4.1.0
  mobile_scanner: ^5.2.3
  permission_handler: ^11.3.1
  connectivity_plus: ^6.1.0
  flutter_local_notifications: ^17.2.3

dev_dependencies:
  flutter_test:
    sdk: flutter
  integration_test:
    sdk: flutter
  flutter_lints: ^4.0.0

flutter:
  uses-material-design: true`
  },
  {
    path: 'lib/firebase_options.dart',
    category: 'config',
    description: 'Shared Firebase configuration matching https://mart-drive.vercel.app',
    content: `// Shared with MART Drive web app (https://mart-drive.vercel.app/)
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError('Platform not supported.');
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDUcT6hVqLHy3pYzwg1oktI7amTpF9Qj4c',
    appId: '1:829348083361:web:d6e91ccec70c2b9d53e2e0',
    messagingSenderId: '829348083361',
    projectId: 'mart-drive',
    authDomain: 'mart-drive.firebaseapp.com',
    storageBucket: 'mart-drive.firebasestorage.app',
    measurementId: 'G-J2ERB07TW0',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDUcT6hVqLHy3pYzwg1oktI7amTpF9Qj4c',
    appId: '1:829348083361:android:e1a90c0ef34b12c8a9d53e',
    messagingSenderId: '829348083361',
    projectId: 'mart-drive',
    storageBucket: 'mart-drive.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDUcT6hVqLHy3pYzwg1oktI7amTpF9Qj4c',
    appId: '1:829348083361:ios:b91c1d8820c75a4ea9d53e',
    messagingSenderId: '829348083361',
    projectId: 'mart-drive',
    storageBucket: 'mart-drive.firebasestorage.app',
    iosBundleId: 'com.mart.drive',
  );
}`
  },
  {
    path: 'lib/main.dart',
    category: 'core',
    description: 'Application entry point initializing Firebase and ProviderScope',
    content: `import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(
    const ProviderScope(
      child: MartDriveApp(),
    ),
  );
}`
  },
  {
    path: 'lib/services/merge_service.dart',
    category: 'services',
    description: 'Port of m3 and span 3-way text merge algorithm for live collaborative notes',
    content: `class MergeResult {
  final String text;
  final bool hasConflict;
  final String? conflictText;
  MergeResult({required this.text, this.hasConflict = false, this.conflictText});
}

class SpanMatch {
  final int prefix;
  final int suffix;
  SpanMatch({required this.prefix, required this.suffix});
}

class MergeService {
  static SpanMatch span(String a, String b) {
    int p = 0;
    final int minLen = a.length < b.length ? a.length : b.length;
    while (p < minLen && a.codeUnitAt(p) == b.codeUnitAt(p)) p++;
    int s = 0;
    while (s < (minLen - p) && a.codeUnitAt(a.length - 1 - s) == b.codeUnitAt(b.length - 1 - s)) s++;
    return SpanMatch(prefix: p, suffix: s);
  }

  static MergeResult m3(String base, String mine, String server) {
    if (mine == server) return MergeResult(text: mine);
    if (mine == base) return MergeResult(text: server);
    if (server == base) return MergeResult(text: mine);

    final mSpan = span(base, mine);
    final int mMidLen = mine.length - mSpan.prefix - mSpan.suffix;
    final sSpan = span(base, server);
    final int sMidLen = server.length - sSpan.prefix - sSpan.suffix;

    final int mStart = mSpan.prefix;
    final int mEndInBase = base.length - mSpan.suffix;
    final int sStart = sSpan.prefix;
    final int sEndInBase = base.length - sSpan.suffix;

    if (mEndInBase <= sStart) {
      final mineChunk = mine.substring(mStart, mStart + mMidLen);
      final serverChunk = server.substring(sStart, sStart + sMidLen);
      return MergeResult(text: '\${base.substring(0, mStart)}\$mineChunk\${base.substring(mEndInBase, sStart)}\$serverChunk\${base.substring(sEndInBase)}');
    }

    if (sEndInBase <= mStart) {
      final serverChunk = server.substring(sStart, sStart + sMidLen);
      final mineChunk = mine.substring(mStart, mStart + mMidLen);
      return MergeResult(text: '\${base.substring(0, sStart)}\$serverChunk\${base.substring(sEndInBase, mStart)}\$mineChunk\${base.substring(mEndInBase)}');
    }

    return MergeResult(text: server, hasConflict: true, conflictText: mine);
  }
}`
  },
  {
    path: 'lib/services/drive_service.dart',
    category: 'services',
    description: 'Google Drive multipart upload, chunked download, permissions & quota',
    content: `import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

class DriveService {
  final Dio _dio = Dio();

  static String getThumbnailUrl(String driveFileId, [int size = 1600]) {
    return 'https://drive.google.com/thumbnail?id=\$driveFileId&sz=w\$size';
  }

  Future<Map<String, dynamic>> uploadFileMultipart({
    required File file,
    required String fileName,
    required String mimeType,
    required String accessToken,
  }) async {
    const uploadUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size';
    // Multipart payload with boundary...
    return {};
  }
}`
  },
  {
    path: 'lib/services/permission_service.dart',
    category: 'services',
    description: 'Role hierarchy (reader < commenter < writer) & MENUS action matrix',
    content: `import '../core/constants.dart';
import '../models/organization.dart';

enum UserRole {
  reader(1), commenter(2), writer(3);
  final int level;
  const UserRole(this.level);
}

class PermissionService {
  static UserRole roleOf({required dynamic item, required String currentUid, required String currentEmail, Organization? org}) {
    if (item.uid == currentUid) return UserRole.writer;
    if (org != null && (org.isOwner(currentEmail) || org.isFounder(currentEmail))) return UserRole.writer;
    return UserRole.reader;
  }
}`
  },
  {
    path: 'lib/services/app_lock_service.dart',
    category: 'services',
    description: 'PBKDF2-SHA256 (150,000 iter) passcode hashing and local_auth biometrics',
    content: `import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'package:pointycastle/key_derivators/pbkdf2.dart';

class AppLockService {
  final _secureStorage = const FlutterSecureStorage();
  final _localAuth = LocalAuthentication();
  // PBKDF2 with 150000 iterations & exponential lockout backoff
}`
  },
  {
    path: 'lib/features/files/all_files_screen.dart',
    category: 'features',
    description: 'All files screen with segments, grid/list toggle, sort & bulk action bar',
    content: `import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AllFilesScreen extends ConsumerStatefulWidget {
  const AllFilesScreen({super.key});
  @override
  ConsumerState<AllFilesScreen> createState() => _AllFilesScreenState();
}

class _AllFilesScreenState extends ConsumerState<AllFilesScreen> {
  String _selectedSegment = 'All';
  bool _isGridView = true;
  // Multi-select bulk actions, star toggle, pull-to-refresh
  @override
  Widget build(BuildContext context) {
    return Scaffold(/* ... */);
  }
}`
  },
  {
    path: 'android/app/src/main/AndroidManifest.xml',
    category: 'config',
    description: 'Android permissions, FileProvider, martdrive:// and App Links intent filters',
    content: `<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.mart.drive">
  <uses-permission android:name="android.permission.INTERNET" />
  <uses-permission android:name="android.permission.CAMERA" />
  <uses-permission android:name="android.permission.USE_BIOMETRIC" />
  <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
  <!-- martdrive:// and https://mart-drive.vercel.app intent filters -->
</manifest>`
  },
  {
    path: 'ios/Runner/Info.plist',
    category: 'config',
    description: 'iOS permissions (Camera, Photo Library, Face ID) and custom URL scheme',
    content: `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDisplayName</key>
  <string>MART Drive</string>
  <key>NSCameraUsageDescription</key>
  <string>MART Drive needs camera access for QR scanning.</string>
  <key>NSFaceIDUsageDescription</key>
  <string>Unlock MART Drive and access your secure vault.</string>
</dict>
</plist>`
  },
  {
    path: 'test/integration_test/app_test.dart',
    category: 'tests',
    description: 'Integration test verifying m3 3-way text merge and conflict handling',
    content: `import 'package:flutter_test/flutter_test.dart';
import 'package:mart_drive/services/merge_service.dart';

void main() {
  test('m3 3-way merge correctly preserves disjoint edits', () {
    const base = 'Header\\n\\nSection 1';
    const mine = 'Header (Modified)\\n\\nSection 1';
    const server = 'Header\\n\\nSection 1 (Server)';
    final result = MergeService.m3(base, mine, server);
    expect(result.hasConflict, isFalse);
  });
}`
  }
];
